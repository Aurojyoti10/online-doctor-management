import { useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import type { Doctor } from '@/types';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { RatingStars } from '@/components/ui/RatingStars';
import { formatCurrency, getInitials } from '@/lib/utils';

interface DoctorAvatarProps { doctor: Doctor; size?: 'sm' | 'md' | 'lg'; }
export function DoctorAvatar({ doctor, size = 'md' }: DoctorAvatarProps) {
  const sizes = { sm: 'w-10 h-10 text-sm', md: 'w-16 h-16 text-lg', lg: 'w-24 h-24 text-2xl' };
  return doctor.avatar ? <img src={doctor.avatar} alt={doctor.name} className={`${sizes[size]} rounded-xl object-cover bg-primary-50`} /> : <div className={`${sizes[size]} rounded-xl bg-primary-50 text-primary-700 flex items-center justify-center font-semibold`}>{getInitials(doctor.name.replace('Dr. ', ''))}</div>;
}

interface DoctorCardProps {
  doctor: Doctor;
  onView?: (doctor: Doctor) => void;
  onBook?: (doctor: Doctor) => void;
  compact?: boolean;
}

export function DoctorCard({ doctor, onView, onBook, compact = false }: DoctorCardProps) {
  const [imageUrl, setImageUrl] = useState<string | undefined>(doctor.avatar);
  useEffect(() => {
    const urls: Record<string, string> = {
      d1: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=160&h=160&fit=crop&crop=face',
      d2: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=160&h=160&fit=crop&crop=face',
      d3: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=160&h=160&fit=crop&crop=face',
      d4: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=160&h=160&fit=crop&crop=face',
      d5: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=160&h=160&fit=crop&crop=face',
      d6: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=160&h=160&fit=crop&crop=face',
      d7: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=160&h=160&fit=crop&crop=face',
    };
    setImageUrl(urls[doctor.id]);
  }, [doctor.id]);
  return (
    <Card className="card-hover p-5 group">
      <div className="flex items-start gap-4">
        {imageUrl ? <img src={imageUrl} alt={doctor.name} className={compact ? 'w-14 h-14 rounded-xl object-cover bg-primary-50 flex-shrink-0' : 'w-20 h-20 rounded-xl object-cover bg-primary-50 flex-shrink-0'} onError={() => setImageUrl(undefined)} /> : <DoctorAvatar doctor={doctor} size={compact ? 'sm' : 'md'} />}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <h3 className="font-semibold text-navy-900 truncate group-hover:text-primary-700 transition-colors">{doctor.name}</h3>
            {doctor.verified && <CheckCircle2 className="w-4 h-4 text-primary-600 fill-primary-50 flex-shrink-0" />}
          </div>
          <p className="text-sm text-navy-600 mt-0.5">{doctor.specializationName}</p>
          <p className="text-xs text-navy-500 mt-1 truncate">{doctor.qualifications}</p>
        </div>
      </div>
      <div className="flex items-center gap-2 mt-4">
        <RatingStars rating={doctor.rating} size="sm" />
        <span className="text-xs text-navy-500">{doctor.reviewCount} reviews</span>
      </div>
      {!compact && <div className="grid grid-cols-2 gap-y-2 mt-4 pt-4 border-t border-navy-100 text-xs text-navy-600"><div><span className="text-navy-400">Experience</span><p className="font-medium text-navy-700 mt-0.5">{doctor.experienceYears} years</p></div><div><span className="text-navy-400">Consultation</span><p className="font-medium text-navy-700 mt-0.5">{formatCurrency(doctor.consultationFee)}</p></div><div className="col-span-2"><span className="text-navy-400">Location</span><p className="font-medium text-navy-700 mt-0.5 truncate">{doctor.location}, {doctor.city}</p></div></div>}
      <div className="flex items-center gap-1.5 mt-4"><Badge variant="success" dot>{doctor.nextAvailable}</Badge>{doctor.onlineConsultation && <Badge variant="teal">Online</Badge>}</div>
      <div className="flex gap-2 mt-4"><Button variant="outline" size="sm" className="flex-1" onClick={() => onView?.(doctor)}>View Profile</Button><Button size="sm" className="flex-1" onClick={() => onBook?.(doctor)}>Book Appointment</Button></div>
    </Card>
  );
}
