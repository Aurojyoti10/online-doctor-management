import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Bell, Search, Menu, LogOut, User as UserIcon, Settings } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { notifications } from '@/data/medical';
import { cn } from '@/lib/utils';

interface DashboardHeaderProps {
  title: string;
  subtitle?: string;
}

export function DashboardHeader({ title, subtitle }: DashboardHeaderProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setProfileOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const userNotifs = notifications.filter((n) => n.role === user?.role).slice(0, 5);
  const unreadCount = userNotifs.filter((n) => !n.read).length;

  const profilePath = user?.role === 'patient' ? '/patient/profile' : user?.role === 'doctor' ? '/doctor/profile' : '/admin/settings';
  const settingsPath = user?.role === 'patient' ? '/patient/settings' : user?.role === 'doctor' ? '/doctor/settings' : '/admin/settings';

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-navy-100">
      <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-lg font-semibold text-navy-900 truncate">{title}</h1>
          {subtitle && <p className="text-xs text-navy-500 truncate hidden sm:block">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate(user?.role === 'patient' ? '/patient/doctors' : '#')}
            className="hidden sm:flex p-2 text-navy-500 hover:text-navy-900 hover:bg-navy-100 rounded-lg transition-colors"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>

          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setNotifOpen(!notifOpen)}
              className="relative p-2 text-navy-500 hover:text-navy-900 hover:bg-navy-100 rounded-lg transition-colors"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-error-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{unreadCount}</span>
              )}
            </button>
            {notifOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-elevated border border-navy-100 animate-slide-up overflow-hidden">
                <div className="px-4 py-3 border-b border-navy-100 flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-navy-900">Notifications</h3>
                  {unreadCount > 0 && <span className="text-xs text-primary-600 font-medium">{unreadCount} new</span>}
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {userNotifs.length === 0 ? (
                    <p className="px-4 py-8 text-center text-sm text-navy-500">No notifications</p>
                  ) : (
                    userNotifs.map((n) => (
                      <div key={n.id} className={cn('px-4 py-3 border-b border-navy-50 hover:bg-navy-50 cursor-pointer', !n.read && 'bg-primary-50/50')}>
                        <div className="flex items-start gap-2">
                          {!n.read && <span className="w-2 h-2 rounded-full bg-primary-500 mt-1.5 flex-shrink-0" />}
                          <div className={cn('flex-1', n.read && 'ml-4')}>
                            <p className="text-sm font-medium text-navy-900">{n.title}</p>
                            <p className="text-xs text-navy-500 mt-0.5">{n.message}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="relative" ref={profileRef}>
            <button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center gap-2 p-1 pr-2 hover:bg-navy-100 rounded-lg transition-colors">
              <UserAvatar name={user?.name || 'User'} size="sm" />
              <span className="hidden sm:block text-sm font-medium text-navy-700 max-w-[120px] truncate">{user?.name}</span>
            </button>
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-elevated border border-navy-100 animate-slide-up overflow-hidden">
                <div className="px-4 py-3 border-b border-navy-100">
                  <p className="text-sm font-semibold text-navy-900 truncate">{user?.name}</p>
                  <p className="text-xs text-navy-500 truncate">{user?.email}</p>
                </div>
                <div className="py-1">
                  <Link to={profilePath} className="flex items-center gap-2.5 px-4 py-2 text-sm text-navy-700 hover:bg-navy-50"><UserIcon className="w-4 h-4" /> Profile</Link>
                  <Link to={settingsPath} className="flex items-center gap-2.5 px-4 py-2 text-sm text-navy-700 hover:bg-navy-50"><Settings className="w-4 h-4" /> Settings</Link>
                  <button onClick={logout} className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-error-600 hover:bg-error-50"><LogOut className="w-4 h-4" /> Logout</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
