import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useState } from 'react';
import { CheckCircle2, ArrowLeft, ArrowRight, Video, MapPin, CreditCard, Wallet, Building2, Calendar, Clock, Check } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { doctors } from '@/data/doctors';
import { patients } from '@/data/patients';
import { useToast } from '@/context/ToastContext';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency, formatDate, generateId } from '@/lib/utils';
import { cn } from '@/lib/utils';
import type { ConsultationType, PaymentMethod } from '@/types';

const steps = ['Consultation Type', 'Date & Time', 'Patient Info', 'Review', 'Payment', 'Confirmation'] as const;

export function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { showToast } = useToast();
  const { user } = useAuth();

  const doctor = doctors.find((d) => d.id === id);
  const patient = patients.find((p) => p.email === user?.email) || patients[0];

  const [step, setStep] = useState(0);
  const [consultationType, setConsultationType] = useState<ConsultationType>('in-person');
  const [selectedDate, setSelectedDate] = useState(searchParams.get('date') || new Date().toISOString().split('T')[0]);
  const [selectedSlot, setSelectedSlot] = useState(searchParams.get('time') || '10:00 AM');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [loading, setLoading] = useState(false);
  const [appointmentId, setAppointmentId] = useState('');

  if (!doctor) {
    return <div className="min-h-screen flex items-center justify-center"><p>Doctor not found</p></div>;
  }

  const timeSlots = ['09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '12:00 PM', '04:00 PM', '04:30 PM', '05:00 PM', '05:30 PM', '06:00 PM'];

  const handlePayment = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setAppointmentId(generateId('APT').toUpperCase());
      setStep(5);
      showToast('success', 'Appointment Booked!', `Your appointment with ${doctor.name} is confirmed.`);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-navy-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-sm text-navy-600 hover:text-navy-900 mb-4">
          <ArrowLeft className="w-4 h-4" /> Back to Doctor Profile
        </button>

        {/* Stepper */}
        <div className="flex items-center justify-between mb-8">
          {steps.slice(0, 5).map((s, i) => (
            <div key={s} className="flex items-center flex-1 last:flex-none">
              <div className={cn('flex items-center gap-2')}>
                <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-colors', i < step ? 'bg-success-500 border-success-500 text-white' : i === step ? 'border-primary-600 text-primary-700 bg-white' : 'border-navy-200 text-navy-400 bg-white')}>
                  {i < step ? <Check className="w-4 h-4" /> : i + 1}
                </div>
                <span className={cn('text-xs font-medium hidden sm:block', i <= step ? 'text-navy-900' : 'text-navy-400')}>{s}</span>
              </div>
              {i < 4 && <div className={cn('h-0.5 flex-1 mx-2 rounded', i < step ? 'bg-success-500' : 'bg-navy-200')} />}
            </div>
          ))}
        </div>

        {/* Step content */}
        {step === 0 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-navy-900 mb-4">Select Consultation Type</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button onClick={() => setConsultationType('in-person')} className={cn('p-4 rounded-xl border-2 text-left transition-colors', consultationType === 'in-person' ? 'border-primary-600 bg-primary-50' : 'border-navy-100 hover:border-navy-200')}>
                <MapPin className="w-6 h-6 text-primary-600 mb-2" />
                <p className="font-semibold text-navy-900">In-person Visit</p>
                <p className="text-xs text-navy-500 mt-1">Visit the doctor at their clinic</p>
                <p className="text-sm font-semibold text-primary-700 mt-2">{formatCurrency(doctor.consultationFee)}</p>
              </button>
              <button onClick={() => setConsultationType('online')} disabled={!doctor.onlineConsultation} className={cn('p-4 rounded-xl border-2 text-left transition-colors disabled:opacity-50 disabled:cursor-not-allowed', consultationType === 'online' ? 'border-primary-600 bg-primary-50' : 'border-navy-100 hover:border-navy-200')}>
                <Video className="w-6 h-6 text-teal-600 mb-2" />
                <p className="font-semibold text-navy-900">Online Consultation</p>
                <p className="text-xs text-navy-500 mt-1">Video call from your home</p>
                <p className="text-sm font-semibold text-primary-700 mt-2">{formatCurrency(doctor.consultationFee)}</p>
              </button>
            </div>
            <div className="flex justify-end mt-6">
              <Button onClick={() => setStep(1)}>Continue <ArrowRight className="w-4 h-4" /></Button>
            </div>
          </Card>
        )}

        {step === 1 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-navy-900 mb-4">Select Date & Time</h2>
            <div>
              <p className="text-xs font-medium text-navy-500 mb-2">Date</p>
              <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="input max-w-xs" min={new Date().toISOString().split('T')[0]} />
            </div>
            <div className="mt-4">
              <p className="text-xs font-medium text-navy-500 mb-2">Available Time Slots</p>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {timeSlots.map((slot) => (
                  <button key={slot} onClick={() => setSelectedSlot(slot)} className={cn('px-2 py-2 text-xs font-medium rounded-lg border transition-colors', selectedSlot === slot ? 'border-primary-600 bg-primary-600 text-white' : 'border-navy-200 text-navy-700 hover:border-primary-300 hover:bg-primary-50')}>{slot}</button>
                ))}
              </div>
            </div>
            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={() => setStep(0)}>Back</Button>
              <Button onClick={() => setStep(2)}>Continue <ArrowRight className="w-4 h-4" /></Button>
            </div>
          </Card>
        )}

        {step === 2 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-navy-900 mb-4">Patient Information</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input label="Full Name" defaultValue={patient.name} />
              <Input label="Email" defaultValue={patient.email} type="email" />
              <Input label="Phone" defaultValue={patient.phone} type="tel" />
              <Input label="Age" defaultValue={patient.age.toString()} type="number" />
              <div>
                <label className="label">Gender</label>
                <select className="input" defaultValue={patient.gender}><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select>
              </div>
              <Input label="Blood Group" defaultValue={patient.bloodGroup} />
            </div>
            <div className="mt-4">
              <label className="label">Reason for Visit</label>
              <textarea className="input resize-none" rows={3} placeholder="Describe your symptoms or reason for consultation" />
            </div>
            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
              <Button onClick={() => setStep(3)}>Continue <ArrowRight className="w-4 h-4" /></Button>
            </div>
          </Card>
        )}

        {step === 3 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-navy-900 mb-4">Review Appointment</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg">
                <div className="w-12 h-12 rounded-xl bg-primary-50 text-primary-700 flex items-center justify-center font-bold">{doctor.name.replace('Dr. ', '').split(' ').map(n => n[0]).join('')}</div>
                <div><p className="font-semibold text-navy-900">{doctor.name}</p><p className="text-xs text-navy-500">{doctor.specializationName}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 bg-navy-50 rounded-lg"><p className="text-xs text-navy-400">Type</p><p className="font-medium text-navy-700 flex items-center gap-1.5 mt-1">{consultationType === 'online' ? <Video className="w-4 h-4" /> : <MapPin className="w-4 h-4" />} {consultationType === 'online' ? 'Online' : 'In-person'}</p></div>
                <div className="p-3 bg-navy-50 rounded-lg"><p className="text-xs text-navy-400">Date</p><p className="font-medium text-navy-700 flex items-center gap-1.5 mt-1"><Calendar className="w-4 h-4" /> {formatDate(selectedDate)}</p></div>
                <div className="p-3 bg-navy-50 rounded-lg"><p className="text-xs text-navy-400">Time</p><p className="font-medium text-navy-700 flex items-center gap-1.5 mt-1"><Clock className="w-4 h-4" /> {selectedSlot}</p></div>
                <div className="p-3 bg-navy-50 rounded-lg"><p className="text-xs text-navy-400">Fee</p><p className="font-medium text-navy-700">{formatCurrency(doctor.consultationFee)}</p></div>
              </div>
              <div className="p-3 bg-navy-50 rounded-lg"><p className="text-xs text-navy-400">Patient</p><p className="font-medium text-navy-700 mt-1">{patient.name}</p></div>
            </div>
            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
              <Button onClick={() => setStep(4)}>Proceed to Payment <ArrowRight className="w-4 h-4" /></Button>
            </div>
          </Card>
        )}

        {step === 4 && (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-navy-900 mb-4">Payment</h2>
            <div className="p-3 bg-primary-50 rounded-lg mb-4 flex items-center justify-between">
              <span className="text-sm text-navy-600">Consultation Fee</span>
              <span className="text-lg font-bold text-navy-900">{formatCurrency(doctor.consultationFee)}</span>
            </div>
            <p className="text-xs font-medium text-navy-500 mb-2">Select Payment Method</p>
            <div className="space-y-2">
              {[
                { id: 'upi' as PaymentMethod, label: 'UPI', desc: 'Pay using GPay, PhonePe, Paytm', icon: Wallet },
                { id: 'card' as PaymentMethod, label: 'Credit/Debit Card', desc: 'Visa, Mastercard, RuPay', icon: CreditCard },
                { id: 'netbanking' as PaymentMethod, label: 'Net Banking', desc: 'All major banks supported', icon: Building2 },
              ].map((method) => (
                <button key={method.id} onClick={() => setPaymentMethod(method.id)} className={cn('w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-colors text-left', paymentMethod === method.id ? 'border-primary-600 bg-primary-50' : 'border-navy-100 hover:border-navy-200')}>
                  <method.icon className={cn('w-5 h-5', paymentMethod === method.id ? 'text-primary-600' : 'text-navy-400')} />
                  <div className="flex-1"><p className="text-sm font-semibold text-navy-900">{method.label}</p><p className="text-xs text-navy-500">{method.desc}</p></div>
                  <div className={cn('w-5 h-5 rounded-full border-2 flex items-center justify-center', paymentMethod === method.id ? 'border-primary-600' : 'border-navy-200')}>{paymentMethod === method.id && <div className="w-2.5 h-2.5 rounded-full bg-primary-600" />}</div>
                </button>
              ))}
            </div>
            {paymentMethod === 'upi' && <Input label="UPI ID" placeholder="yourname@upi" className="mt-4" />}
            {paymentMethod === 'card' && (
              <div className="grid grid-cols-2 gap-3 mt-4">
                <Input label="Card Number" placeholder="1234 5678 9012 3456" className="col-span-2" />
                <Input label="Expiry" placeholder="MM/YY" /><Input label="CVV" placeholder="123" />
              </div>
            )}
            <div className="flex justify-between mt-6">
              <Button variant="outline" onClick={() => setStep(3)}>Back</Button>
              <Button onClick={handlePayment} loading={loading}>Pay {formatCurrency(doctor.consultationFee)}</Button>
            </div>
          </Card>
        )}

        {step === 5 && (
          <Card className="p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-success-50 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-12 h-12 text-success-500" />
            </div>
            <h2 className="text-xl font-bold text-navy-900">Appointment booked successfully!</h2>
            <p className="text-sm text-navy-500 mt-2">Your appointment with {doctor.name} is confirmed for {formatDate(selectedDate)} at {selectedSlot}.</p>
            <div className="mt-4 p-4 bg-navy-50 rounded-lg inline-block">
              <p className="text-xs text-navy-400">Appointment ID</p>
              <p className="text-lg font-bold font-mono text-navy-900">{appointmentId}</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
              <Button onClick={() => navigate('/patient/appointments')}>View Appointments</Button>
              <Button variant="outline" onClick={() => navigate('/patient/dashboard')}>Go to Dashboard</Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
