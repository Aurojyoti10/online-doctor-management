import { useState } from 'react';
import { Plus, Trash2, Calendar, Plane } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { useToast } from '@/context/ToastContext';
import { doctors } from '@/data/doctors';
import { cn } from '@/lib/utils';
import { LayoutDashboard, CalendarDays, Users, Clock, FileText, Star, IndianRupee, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: Users },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileText },
  { label: 'Reviews', path: '/doctor/reviews', icon: Star },
  { label: 'Earnings', path: '/doctor/earnings', icon: IndianRupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const fullDays: Record<string, string> = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

export function DoctorAvailability() {
  const { showToast } = useToast();
  const doctor = doctors.find(d => d.id === 'd1')!;
  const [schedule, setSchedule] = useState(doctor.availability);
  const [editDay, setEditDay] = useState<string | null>(null);
  const [onlineEnabled, setOnlineEnabled] = useState(doctor.onlineConsultation);
  const [consultationDuration, setConsultationDuration] = useState(30);
  const [blockedDates, setBlockedDates] = useState<string[]>([]);
  const [newBlockedDate, setNewBlockedDate] = useState('');

  const toggleDay = (day: string) => {
    setSchedule(prev => prev.map(d => d.day === day ? { ...d, enabled: !d.enabled, ranges: !d.enabled ? [{ start: '09:00', end: '13:00' }] : [] } : d));
    showToast('success', 'Schedule Updated', `${fullDays[day]} availability updated.`);
  };

  const addBlockedDate = () => {
    if (newBlockedDate && !blockedDates.includes(newBlockedDate)) {
      setBlockedDates([...blockedDates, newBlockedDate]);
      setNewBlockedDate('');
      showToast('success', 'Date Blocked', 'The selected date has been blocked.');
    }
  };

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Availability" headerSubtitle="Manage your schedule and working hours" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly schedule */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader><CardTitle>Weekly Schedule</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {schedule.map((day) => (
                <div key={day.day} className={cn('flex items-center justify-between p-3 rounded-lg border', day.enabled ? 'border-navy-100 bg-white' : 'border-navy-50 bg-navy-50/50')}>
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className={cn('w-12 text-sm font-semibold', day.enabled ? 'text-navy-900' : 'text-navy-400')}>{day.day}</div>
                    <div className="flex-1 min-w-0">
                      {day.enabled ? (
                        <div className="flex flex-wrap gap-2">
                          {day.ranges.map((r, i) => <span key={i} className="badge-primary text-[10px]">{r.start} - {r.end}</span>)}
                        </div>
                      ) : (
                        <span className="text-xs text-error-500">Unavailable</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={day.enabled} onChange={() => toggleDay(day.day)} className="sr-only peer" />
                      <div className="w-10 h-5.5 bg-navy-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4.5 after:w-4.5 after:transition-all peer-checked:bg-primary-600" style={{ width: '40px', height: '22px' }}></div>
                    </label>
                    {day.enabled && <Button variant="ghost" size="sm" onClick={() => setEditDay(day.day)}>Edit</Button>}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Settings */}
        <div className="space-y-6">
          <Card>
            <CardHeader><CardTitle>Consultation Settings</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div><p className="text-sm font-medium text-navy-900">Online Consultation</p><p className="text-xs text-navy-500">Allow video consultations</p></div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={onlineEnabled} onChange={(e) => { setOnlineEnabled(e.target.checked); showToast('success', 'Updated', `Online consultation ${e.target.checked ? 'enabled' : 'disabled'}.`); }} className="sr-only peer" />
                  <div className="w-11 h-6 bg-navy-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              <div>
                <label className="label">Consultation Duration</label>
                <select className="input" value={consultationDuration} onChange={(e) => setConsultationDuration(Number(e.target.value))}>
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={45}>45 minutes</option>
                  <option value={60}>60 minutes</option>
                </select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><Plane className="w-4 h-4 text-primary-600" /> Block Dates / Holidays</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <input type="date" value={newBlockedDate} onChange={(e) => setNewBlockedDate(e.target.value)} className="input flex-1" />
                <Button size="sm" onClick={addBlockedDate}><Plus className="w-4 h-4" /></Button>
              </div>
              {blockedDates.length > 0 ? (
                <div className="space-y-2">
                  {blockedDates.map((d) => (
                    <div key={d} className="flex items-center justify-between p-2 bg-navy-50 rounded-lg">
                      <span className="text-sm text-navy-700 flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-navy-400" /> {d}</span>
                      <button onClick={() => setBlockedDates(blockedDates.filter(b => b !== d))} className="text-error-500 hover:text-error-700"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-navy-400 text-center py-2">No blocked dates</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Modal open={!!editDay} onClose={() => setEditDay(null)} title={`Edit ${editDay ? fullDays[editDay] : ''} Schedule`}>
        <div className="p-5">
          <p className="text-sm text-navy-500 mb-4">Add or remove time slots for this day.</p>
          {editDay && schedule.find(d => d.day === editDay)?.ranges.map((r, i) => (
            <div key={i} className="flex items-center gap-2 mb-2">
              <input type="time" defaultValue={r.start} className="input flex-1" />
              <span className="text-navy-400">to</span>
              <input type="time" defaultValue={r.end} className="input flex-1" />
              <button className="text-error-500 hover:text-error-700 p-1"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
          <Button variant="outline" size="sm" className="w-full mt-3"><Plus className="w-4 h-4" /> Add Time Slot</Button>
          <div className="flex gap-2 mt-5">
            <Button variant="outline" className="flex-1" onClick={() => setEditDay(null)}>Cancel</Button>
            <Button className="flex-1" onClick={() => { setEditDay(null); showToast('success', 'Schedule Saved', 'Your availability has been updated.'); }}>Save Schedule</Button>
          </div>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
