import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { StatCard } from '@/components/shared/StatCard';
import { EmptyState } from '@/components/ui/States';
import { RatingStars } from '@/components/ui/RatingStars';
import { reviews } from '@/data/medical';
import { formatDate, formatCurrency } from '@/lib/utils';
import { TrendingUp, IndianRupee, Calendar, FileText, Star, Users } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { LayoutDashboard, CalendarDays, Users as UsersIcon, Clock, FileText as FileTextIcon, Star as StarIcon, IndianRupee as Rupee, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: UsersIcon },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileTextIcon },
  { label: 'Reviews', path: '/doctor/reviews', icon: StarIcon },
  { label: 'Earnings', path: '/doctor/earnings', icon: Rupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

const earningsData = [
  { month: 'Apr', earnings: 42000 }, { month: 'May', earnings: 48000 }, { month: 'Jun', earnings: 55000 },
  { month: 'Jul', earnings: 51000 }, { month: 'Aug', earnings: 63000 }, { month: 'Sep', earnings: 58000 },
];

const apptStats = [
  { type: 'Completed', count: 45 }, { type: 'Pending', count: 5 }, { type: 'Cancelled', count: 8 },
];

export function DoctorEarnings() {
  const totalEarnings = earningsData.reduce((sum, d) => sum + d.earnings, 0);
  const monthlyAvg = Math.round(totalEarnings / earningsData.length);

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Earnings" headerSubtitle="Track your revenue and consultation statistics" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Earnings" value={formatCurrency(totalEarnings)} icon={IndianRupee} color="success" trend={{ value: "+18%", up: true }} />
        <StatCard label="Monthly Average" value={formatCurrency(monthlyAvg)} icon={TrendingUp} color="primary" />
        <StatCard label="Total Consultations" value={58} icon={Calendar} color="teal" />
        <StatCard label="Avg Rating" value="4.8" icon={Star} color="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Monthly Earnings</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={earningsData}>
                <defs>
                  <linearGradient id="colorEarnings" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip formatter={(v: any) => [formatCurrency(Number(v)), 'Earnings']} contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Area type="monotone" dataKey="earnings" stroke="#2563eb" strokeWidth={2} fill="url(#colorEarnings)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Appointment Statistics</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={apptStats}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="type" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Bar dataKey="count" fill="#2dd4bf" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader><CardTitle>Patient Reviews</CardTitle></CardHeader>
        <CardContent>
          {reviews.filter(r => r.doctorId === 'd1').length === 0 ? (
            <EmptyState icon={Star} title="No reviews yet" description="Patient reviews will appear here." />
          ) : (
            <div className="space-y-3">
              {reviews.filter(r => r.doctorId === 'd1').map((review) => (
                <div key={review.id} className="p-3 bg-navy-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-navy-900">{review.patientName}</p>
                      <p className="text-xs text-navy-400">{formatDate(review.date)}</p>
                    </div>
                    <RatingStars rating={review.rating} size="sm" />
                  </div>
                  <p className="text-sm text-navy-600 mt-2">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
