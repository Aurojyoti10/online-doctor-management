import { useNavigate } from 'react-router-dom';
import { Calendar, IndianRupee, TrendingUp, Video, MapPin, ArrowRight } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { StatCard } from '@/components/shared/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/Badge';
import { EmptyState } from '@/components/ui/States';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { useAuth } from '@/context/AuthContext';
import { appointments } from '@/data/appointments';
import { getGreeting, formatDate, formatCurrency } from '@/lib/utils';
import { LayoutDashboard, CalendarDays, Users as UsersIcon, Clock, FileText, Star, IndianRupee as Rupee, User, Settings, LogOut } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: UsersIcon },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileText },
  { label: 'Reviews', path: '/doctor/reviews', icon: Star },
  { label: 'Earnings', path: '/doctor/earnings', icon: Rupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

const revenueData = [
  { day: 'Mon', revenue: 4500 }, { day: 'Tue', revenue: 3200 }, { day: 'Wed', revenue: 5800 },
  { day: 'Thu', revenue: 2400 }, { day: 'Fri', revenue: 6100 }, { day: 'Sat', revenue: 3800 }, { day: 'Sun', revenue: 0 },
];

export function DoctorDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const doctorAppointments = appointments.filter(a => a.doctorId === 'd1');
  const todayAppointments = doctorAppointments.filter(a => a.date === '2026-09-09');
  const pendingRequests = doctorAppointments.filter(a => a.status === 'pending');
  const totalPatients = new Set(doctorAppointments.map(a => a.patientId)).size;
  const todayEarnings = doctorAppointments.filter(a => a.date === '2026-09-09' && a.paymentStatus === 'paid').reduce((sum, a) => sum + a.fee, 0);

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle={`${getGreeting()}, ${user?.name?.split(' ')[0] || 'Dr. Sarah'}`} headerSubtitle="Here's your practice overview" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Today's Appointments" value={todayAppointments.length} icon={Calendar} color="primary" />
        <StatCard label="Pending Requests" value={pendingRequests.length} icon={Clock} color="warning" />
        <StatCard label="Total Patients" value={totalPatients} icon={UsersIcon} color="teal" />
        <StatCard label="Today's Earnings" value={formatCurrency(todayEarnings)} icon={IndianRupee} color="success" trend={{ value: "+12%", up: true }} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Today's schedule */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Today's Schedule</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => navigate('/doctor/appointments')}>View all</Button>
              </div>
            </CardHeader>
            <CardContent>
              {todayAppointments.length === 0 ? (
                <EmptyState icon={CalendarDays} title="No appointments today" description="Your schedule is clear for today." />
              ) : (
                <div className="space-y-3">
                  {todayAppointments.map((apt) => (
                    <div key={apt.id} className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg hover:bg-navy-100 transition-colors cursor-pointer" onClick={() => navigate(`/doctor/appointments/${apt.id}`)}>
                      <div className="text-center flex-shrink-0 w-16">
                        <p className="text-sm font-bold text-primary-700">{apt.time}</p>
                      </div>
                      <div className="h-10 w-px bg-navy-200" />
                      <UserAvatar name={apt.patientName} size="sm" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-navy-900 truncate">{apt.patientName}</p>
                        <p className="text-xs text-navy-500">{apt.reason}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-navy-400 flex items-center gap-0.5">{apt.consultationType === 'online' ? <Video className="w-3 h-3" /> : <MapPin className="w-3 h-3" />} {apt.consultationType === 'online' ? 'Online' : 'In-person'}</span>
                        </div>
                      </div>
                      <StatusBadge status={apt.status} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Revenue chart */}
          <Card>
            <CardHeader><CardTitle>Weekly Revenue</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                  <Tooltip formatter={(v: any) => [formatCurrency(Number(v)), 'Revenue']} contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                  <Bar dataKey="revenue" fill="#2563eb" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Pending requests */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Pending Requests</CardTitle>
                {pendingRequests.length > 0 && <span className="badge-warning">{pendingRequests.length} new</span>}
              </div>
            </CardHeader>
            <CardContent>
              {pendingRequests.length === 0 ? (
                <EmptyState icon={Clock} title="No pending requests" description="All requests have been handled." />
              ) : (
                <div className="space-y-3">
                  {pendingRequests.map((apt) => (
                    <div key={apt.id} className="p-3 border border-warning-200 bg-warning-50/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <UserAvatar name={apt.patientName} size="xs" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-navy-900 truncate">{apt.patientName}</p>
                          <p className="text-xs text-navy-500">{formatDate(apt.date)} at {apt.time}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2">
                        <Button size="sm" className="flex-1" onClick={() => navigate(`/doctor/appointments/${apt.id}`)}>Review</Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent patients */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Patients</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => navigate('/doctor/patients')}>View all</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {doctorAppointments.slice(0, 4).map((apt) => (
                  <div key={apt.id} className="flex items-center gap-2 p-2 hover:bg-navy-50 rounded-lg cursor-pointer" onClick={() => navigate(`/doctor/patients/${apt.patientId}`)}>
                    <UserAvatar name={apt.patientName} size="xs" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-navy-900 truncate">{apt.patientName}</p>
                      <p className="text-xs text-navy-400">{apt.patientAge} yrs • {apt.patientGender}</p>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-navy-300" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
