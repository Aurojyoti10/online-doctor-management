import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X, Play, Video, MapPin } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/Badge';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { EmptyState } from '@/components/ui/States';
import { ConfirmDialog } from '@/components/ui/Modal';
import { useToast } from '@/context/ToastContext';
import { appointments } from '@/data/appointments';
import { formatDate } from '@/lib/utils';
import { LayoutDashboard, CalendarDays, Users, Clock, FileText, Star, IndianRupee, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: Users },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileText },
  { label: 'Reviews', path: '/doctor/reviews', icon: Star },
  { label: 'Earnings', path: '/doctor/earnings', icon: IndianRupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

const tabs = ['Today', 'Upcoming', 'Pending', 'Completed'] as const;

export function DoctorAppointments() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<typeof tabs[number]>('Today');
  const [rejectTarget, setRejectTarget] = useState<string | null>(null);
  const [localAppts, setLocalAppts] = useState(appointments);

  const doctorAppts = localAppts.filter(a => a.doctorId === 'd1');

  const filtered = doctorAppts.filter(a => {
    if (activeTab === 'Today') return a.date === '2026-09-09';
    if (activeTab === 'Upcoming') return a.status === 'confirmed' && a.date !== '2026-09-09';
    if (activeTab === 'Pending') return a.status === 'pending';
    if (activeTab === 'Completed') return a.status === 'completed';
    return true;
  });

  const handleAccept = (id: string) => {
    setLocalAppts(prev => prev.map(a => a.id === id ? { ...a, status: 'confirmed' as const } : a));
    showToast('success', 'Appointment Accepted', 'The patient has been notified.');
  };

  const handleReject = () => {
    setLocalAppts(prev => prev.map(a => a.id === rejectTarget ? { ...a, status: 'rejected' as const } : a));
    showToast('info', 'Appointment Rejected', 'The patient has been notified.');
    setRejectTarget(null);
  };

  const handleComplete = (id: string) => {
    setLocalAppts(prev => prev.map(a => a.id === id ? { ...a, status: 'completed' as const } : a));
    showToast('success', 'Consultation Completed', 'Navigating to consultation workspace...');
    navigate(`/doctor/consultation/${id}`);
  };

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Appointments" headerSubtitle="Manage your patient appointments" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="flex gap-1 p-1 bg-white border border-navy-100 rounded-xl mb-6 w-full sm:w-auto sm:inline-flex overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 sm:flex-none px-4 py-2 text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${activeTab === tab ? 'bg-primary-50 text-primary-700' : 'text-navy-500 hover:text-navy-700'}`}>{tab}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card><EmptyState icon={CalendarDays} title="No appointments" description={activeTab === 'Today' ? 'You have no appointments scheduled for today.' : 'No appointments in this category.'} /></Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((apt) => (
            <Card key={apt.id} className={`p-4 ${apt.status === 'pending' ? 'border-warning-200 bg-warning-50/30' : ''}`}>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="text-center flex-shrink-0 w-14 sm:w-16">
                  <p className="text-sm font-bold text-primary-700">{apt.time}</p>
                  <p className="text-[10px] text-navy-400">{formatDate(apt.date)}</p>
                </div>
                <div className="hidden sm:block h-10 w-px bg-navy-200" />
                <UserAvatar name={apt.patientName} size="sm" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-navy-900 text-sm truncate">{apt.patientName}</p>
                    <StatusBadge status={apt.status} />
                  </div>
                  <p className="text-xs text-navy-500 mt-0.5">{apt.patientAge} yrs • {apt.patientGender} • {apt.reason}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-navy-400 flex items-center gap-0.5">{apt.consultationType === 'online' ? <Video className="w-3 h-3" /> : <MapPin className="w-3 h-3" />} {apt.consultationType === 'online' ? 'Online' : 'In-person'}</span>
                    {apt.tokenNumber && <span className="text-[10px] text-navy-400">Token #{apt.tokenNumber}</span>}
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button variant="outline" size="sm" onClick={() => navigate(`/doctor/patients/${apt.patientId}`)}>View Patient</Button>
                  {apt.status === 'pending' && (
                    <>
                      <Button size="sm" onClick={() => handleAccept(apt.id)}><Check className="w-3.5 h-3.5" /> Accept</Button>
                      <Button variant="ghost" size="sm" className="text-error-600" onClick={() => setRejectTarget(apt.id)}><X className="w-3.5 h-3.5" /></Button>
                    </>
                  )}
                  {apt.status === 'confirmed' && (
                    <Button size="sm" onClick={() => handleComplete(apt.id)}><Play className="w-3.5 h-3.5" /> Start</Button>
                  )}
                  {apt.status === 'completed' && apt.prescriptionId && (
                    <Button variant="outline" size="sm" onClick={() => navigate(`/doctor/prescriptions`)}><FileText className="w-3.5 h-3.5" /> Rx</Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <ConfirmDialog open={!!rejectTarget} onClose={() => setRejectTarget(null)} onConfirm={handleReject} title="Reject Appointment?" description="The patient will be notified that this appointment has been rejected. They can book with another doctor." confirmLabel="Yes, Reject" />
    </DashboardLayout>
  );
}
