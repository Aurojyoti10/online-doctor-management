import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Input, Textarea } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { RatingStars } from '@/components/ui/RatingStars';
import { EmptyState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { reviews } from '@/data/medical';
import { formatDate } from '@/lib/utils';
import { Star } from 'lucide-react';
import { LayoutDashboard, CalendarDays, Users, Clock, FileText, Star as StarIcon, IndianRupee, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: Users },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileText },
  { label: 'Reviews', path: '/doctor/reviews', icon: StarIcon },
  { label: 'Earnings', path: '/doctor/earnings', icon: IndianRupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

export function DoctorReviews() {
  const { showToast } = useToast();
  const doctorReviews = reviews.filter(r => r.doctorId === 'd1');
  const avgRating = doctorReviews.length > 0 ? (doctorReviews.reduce((s, r) => s + r.rating, 0) / doctorReviews.length) : 0;
  const ratingBreakdown = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  doctorReviews.forEach(r => { ratingBreakdown[r.rating as keyof typeof ratingBreakdown]++; });

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Reviews" headerSubtitle="Patient feedback and ratings" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="p-5 text-center">
          <p className="text-4xl font-bold text-navy-900">{avgRating.toFixed(1)}</p>
          <RatingStars rating={avgRating} showValue={false} size="lg" />
          <p className="text-sm text-navy-500 mt-2">{doctorReviews.length} reviews</p>
        </Card>
        <Card className="lg:col-span-2 p-5">
          <h3 className="font-semibold text-navy-900 mb-3 text-sm">Rating Breakdown</h3>
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((star) => (
              <div key={star} className="flex items-center gap-2">
                <span className="text-xs text-navy-500 w-3">{star}</span>
                <Star className="w-3 h-3 text-warning-400 fill-current" />
                <div className="flex-1 h-2 bg-navy-100 rounded-full overflow-hidden">
                  <div className="h-full bg-warning-400 rounded-full" style={{ width: `${(ratingBreakdown[star as keyof typeof ratingBreakdown] / doctorReviews.length) * 100 || 0}%` }} />
                </div>
                <span className="text-xs text-navy-500 w-6 text-right">{ratingBreakdown[star as keyof typeof ratingBreakdown]}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader><CardTitle>All Reviews</CardTitle></CardHeader>
        <CardContent>
          {doctorReviews.length === 0 ? (
            <EmptyState icon={Star} title="No reviews yet" description="Patient reviews will appear here after consultations." />
          ) : (
            <div className="space-y-3">
              {doctorReviews.map((review) => (
                <div key={review.id} className="p-4 bg-navy-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-semibold">{review.patientName.split(' ').map(n => n[0]).join('')}</div>
                      <div><p className="text-sm font-semibold text-navy-900">{review.patientName}</p><p className="text-xs text-navy-400">{formatDate(review.date)}</p></div>
                    </div>
                    <RatingStars rating={review.rating} size="sm" />
                  </div>
                  <p className="text-sm text-navy-600 mt-2">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}

export function DoctorProfile() {
  const { showToast } = useToast();
  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="My Profile" headerSubtitle="Manage your professional information" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="max-w-3xl mx-auto space-y-6">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-primary-50 text-primary-700 flex items-center justify-center text-2xl font-bold">SW</div>
            <div>
              <h2 className="text-xl font-bold text-navy-900">Dr. Sarah Wilson</h2>
              <p className="text-sm text-navy-500">General Physician • MBBS, MD</p>
              <div className="flex items-center gap-2 mt-1">
                <RatingStars rating={4.8} size="sm" />
                <span className="text-xs text-navy-400">• 12 years experience</span>
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle>Professional Information</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input label="Full Name" defaultValue="Dr. Sarah Wilson" />
              <Input label="Email" defaultValue="sarah.wilson@careconnect.in" />
              <Input label="Phone" defaultValue="+91 98765 43210" />
              <Input label="Specialization" defaultValue="General Physician" disabled />
              <Input label="Qualifications" defaultValue="MBBS, MD (General Medicine)" />
              <Input label="Experience (years)" defaultValue="12" type="number" />
              <Input label="Consultation Fee" defaultValue="500" type="number" />
              <Input label="Hospital/Clinic" defaultValue="Apollo Clinic" />
            </div>
            <div className="mt-4">
              <Textarea label="About" rows={4} defaultValue="Dr. Sarah Wilson is a seasoned General Physician with over 12 years of experience in primary care, preventive health, and chronic disease management." />
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button variant="outline">Cancel</Button>
              <Button onClick={() => showToast('success', 'Profile Updated', 'Your professional information has been saved.')}>Save Changes</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Languages & Services</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-semibold text-navy-900 mb-2">Languages</p>
                <div className="flex flex-wrap gap-2">
                  {['English', 'Tamil', 'Hindi'].map(l => <span key={l} className="badge-primary">{l}</span>)}
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-navy-900 mb-2">Services</p>
                <div className="flex flex-wrap gap-2">
                  {['General Consultation', 'Follow-up', 'Diabetes Management', 'Preventive Health'].map(s => <span key={s} className="badge-teal">{s}</span>)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

export function DoctorSettings() {
  const { showToast } = useToast();
  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Settings" headerSubtitle="Manage your preferences" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader><CardTitle>Notifications</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {['New appointment requests', 'Appointment reminders', 'Patient messages', 'Payment notifications'].map(item => (
              <div key={item} className="flex items-center justify-between py-2">
                <p className="text-sm font-medium text-navy-900">{item}</p>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked className="sr-only peer" onChange={() => showToast('success', 'Updated', `${item} preference updated.`)} />
                  <div className="w-11 h-6 bg-navy-200 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Security</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-navy-900">Change password</p><p className="text-xs text-navy-500">Update your account password</p></div>
              <Button variant="outline" size="sm" onClick={() => showToast('info', 'Change Password', 'Password change form will open here.')}>Change</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
