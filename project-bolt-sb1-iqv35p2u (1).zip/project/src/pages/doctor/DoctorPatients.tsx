import { useNavigate, useParams } from 'react-router-dom';
import { Mail, Phone, Droplet, AlertCircle, Activity, Calendar } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { StatusBadge } from '@/components/ui/Badge';
import { EmptyState } from '@/components/ui/States';
import { patients } from '@/data/patients';
import { appointments } from '@/data/appointments';
import { prescriptions } from '@/data/medical';
import { formatDate } from '@/lib/utils';
import { useState } from 'react';
import { LayoutDashboard, CalendarDays, Users, Clock, FileText, Star, IndianRupee, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/doctor/dashboard', icon: LayoutDashboard },
  { label: 'Appointments', path: '/doctor/appointments', icon: CalendarDays },
  { label: 'Patients', path: '/doctor/patients', icon: Users },
  { label: 'Availability', path: '/doctor/availability', icon: Clock },
  { label: 'Prescriptions', path: '/doctor/prescriptions', icon: FileText },
  { label: 'Reviews', path: '/doctor/reviews', icon: Star },
  { label: 'Earnings', path: '/doctor/earnings', icon: IndianRupee },
  { label: 'Profile', path: '/doctor/profile', icon: User },
  { label: 'Settings', path: '/doctor/settings', icon: Settings },
];

export function DoctorPatients() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const doctorPatientIds = new Set(appointments.filter(a => a.doctorId === 'd1').map(a => a.patientId));
  const doctorPatients = patients.filter(p => doctorPatientIds.has(p.id));
  const filtered = doctorPatients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.email.toLowerCase().includes(search.toLowerCase()));

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Patients" headerSubtitle="View and manage patient records" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <input type="text" placeholder="Search patients by name or email..." value={search} onChange={(e) => setSearch(e.target.value)} className="input mb-6 max-w-md" />

      {filtered.length === 0 ? (
        <Card><EmptyState icon={Users} title="No patients found" description="No patients match your search." /></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <Card key={p.id} className="card-hover p-4 cursor-pointer" onClick={() => navigate(`/doctor/patients/${p.id}`)}>
              <div className="flex items-center gap-3">
                <UserAvatar name={p.name} size="md" />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-navy-900 text-sm truncate">{p.name}</p>
                  <p className="text-xs text-navy-500">{p.age} yrs • {p.gender}</p>
                  <p className="text-xs text-navy-400 mt-0.5">{p.appointmentsCount} visits</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                {p.conditions.slice(0, 2).map((c, i) => <span key={i} className="badge-warning text-[10px]">{c}</span>)}
                {p.allergies.slice(0, 1).map((a, i) => <span key={i} className="badge-error text-[10px]">{a}</span>)}
              </div>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}

export function DoctorPatientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'prescriptions' | 'reports'>('overview');
  const patient = patients.find(p => p.id === id);
  const patientAppts = appointments.filter(a => a.patientId === id);
  const patientRx = prescriptions.filter(p => p.patientId === id);

  if (!patient) return <div className="min-h-screen flex items-center justify-center"><p>Patient not found</p></div>;

  const tabs = [
    { id: 'overview' as const, label: 'Overview' },
    { id: 'history' as const, label: 'Medical History' },
    { id: 'prescriptions' as const, label: 'Prescriptions' },
    { id: 'reports' as const, label: 'Reports' },
  ];

  return (
    <DashboardLayout items={navItems} title="Doctor Portal" headerTitle="Patient Details" headerSubtitle={patient.name} footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Patient header */}
        <Card className="p-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <UserAvatar name={patient.name} size="lg" />
            <div className="flex-1">
              <h2 className="text-xl font-bold text-navy-900">{patient.name}</h2>
              <p className="text-sm text-navy-500">{patient.age} years • {patient.gender} • Blood: {patient.bloodGroup}</p>
              <div className="flex items-center gap-3 mt-2 text-xs text-navy-500">
                <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {patient.email}</span>
                <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {patient.phone}</span>
              </div>
            </div>
            <Button onClick={() => navigate('/doctor/appointments')}>Back to Appointments</Button>
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-white border border-navy-100 rounded-xl w-full sm:w-auto sm:inline-flex overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 sm:flex-none px-4 py-2 text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${activeTab === tab.id ? 'bg-primary-50 text-primary-700' : 'text-navy-500 hover:text-navy-700'}`}>{tab.label}</button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="p-5">
              <h3 className="font-semibold text-navy-900 text-sm mb-3 flex items-center gap-2"><Droplet className="w-4 h-4 text-error-500" /> Allergies</h3>
              <div className="flex flex-wrap gap-2">
                {patient.allergies.length > 0 ? patient.allergies.map((a, i) => <span key={i} className="badge-error">{a}</span>) : <span className="text-sm text-navy-400">No known allergies</span>}
              </div>
            </Card>
            <Card className="p-5">
              <h3 className="font-semibold text-navy-900 text-sm mb-3 flex items-center gap-2"><Activity className="w-4 h-4 text-warning-500" /> Existing Conditions</h3>
              <div className="flex flex-wrap gap-2">
                {patient.conditions.length > 0 ? patient.conditions.map((c, i) => <span key={i} className="badge-warning">{c}</span>) : <span className="text-sm text-navy-400">No existing conditions</span>}
              </div>
            </Card>
            <Card className="p-5">
              <h3 className="font-semibold text-navy-900 text-sm mb-3 flex items-center gap-2"><Calendar className="w-4 h-4 text-primary-500" /> Recent Appointments</h3>
              <div className="space-y-2">
                {patientAppts.slice(0, 3).map((a) => (
                  <div key={a.id} className="flex items-center justify-between text-xs">
                    <span className="text-navy-600">{formatDate(a.date)}</span>
                    <StatusBadge status={a.status} />
                  </div>
                ))}
              </div>
            </Card>
            <Card className="p-5">
              <h3 className="font-semibold text-navy-900 text-sm mb-3 flex items-center gap-2"><AlertCircle className="w-4 h-4 text-teal-500" /> Quick Info</h3>
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-navy-500">Total visits</span><span className="font-medium text-navy-700">{patient.appointmentsCount}</span></div>
                <div className="flex justify-between"><span className="text-navy-500">Registered</span><span className="font-medium text-navy-700">{formatDate(patient.registeredDate)}</span></div>
                <div className="flex justify-between"><span className="text-navy-500">City</span><span className="font-medium text-navy-700">{patient.city}</span></div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'history' && (
          <Card className="p-5">
            <h3 className="font-semibold text-navy-900 mb-4">Consultation History</h3>
            <div className="space-y-3">
              {patientAppts.map((a) => (
                <div key={a.id} className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg">
                  <div className="text-xs text-navy-400 w-24 flex-shrink-0">{formatDate(a.date)}</div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-navy-900">{a.reason}</p>
                    <p className="text-xs text-navy-500">{a.doctorName}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </div>
              ))}
            </div>
          </Card>
        )}

        {activeTab === 'prescriptions' && (
          <Card className="p-5">
            <h3 className="font-semibold text-navy-900 mb-4">Prescriptions</h3>
            {patientRx.length === 0 ? (
              <EmptyState icon={FileText} title="No prescriptions" description="No prescriptions have been issued for this patient." />
            ) : (
              <div className="space-y-3">
                {patientRx.map((rx) => (
                  <div key={rx.id} className="p-3 border border-navy-100 rounded-lg">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-navy-900">{rx.diagnosis}</p>
                      <span className="text-xs text-navy-400">{formatDate(rx.date)}</span>
                    </div>
                    <p className="text-xs text-navy-500 mt-1">{rx.medicines.length} medicines • {rx.doctorName}</p>
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}

        {activeTab === 'reports' && (
          <Card><EmptyState icon={FileText} title="No reports available" description="Lab reports and test results will appear here." /></Card>
        )}
      </div>
    </DashboardLayout>
  );
}
