import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, HeartPulse, Bell } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { StatCard } from '@/components/shared/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/Badge';
import { AppointmentCard } from '@/components/shared/AppointmentCard';
import { EmptyState } from '@/components/ui/States';
import { useAuth } from '@/context/AuthContext';
import { appointments } from '@/data/appointments';
import { doctors } from '@/data/doctors';
import { getGreeting, formatDate } from '@/lib/utils';
import { LayoutDashboard, Search, CalendarDays, FileText, Activity, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/patient/dashboard', icon: LayoutDashboard },
  { label: 'Find Doctors', path: '/patient/doctors', icon: Search },
  { label: 'Appointments', path: '/patient/appointments', icon: CalendarDays },
  { label: 'Prescriptions', path: '/patient/prescriptions', icon: FileText },
  { label: 'Medical History', path: '/patient/medical-history', icon: Activity },
  { label: 'Profile', path: '/patient/profile', icon: User },
  { label: 'Settings', path: '/patient/settings', icon: Settings },
];

export function PatientDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const patientAppointments = appointments.filter(a => a.patientId === 'p1');
  const upcoming = patientAppointments.filter(a => a.status === 'confirmed' || a.status === 'pending').sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const past = patientAppointments.filter(a => a.status === 'completed');
  const prescriptions = past.filter(a => a.prescriptionId);
  const recommendedDoctors = doctors.slice(0, 3);

  return (
    <DashboardLayout items={navItems} title="Patient Portal" headerTitle={`${getGreeting()}, ${user?.name?.split(' ')[0] || 'Alex'}`} headerSubtitle="Here's your health overview" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Upcoming Appointments" value={upcoming.length} icon={Calendar} color="primary" />
        <StatCard label="Past Appointments" value={past.length} icon={Clock} color="teal" />
        <StatCard label="Prescriptions" value={prescriptions.length} icon={FileText} color="success" />
        <StatCard label="Health Score" value="85%" icon={HeartPulse} color="warning" trend={{ value: "+5%", up: true }} />
      </div>

      {/* Next appointment highlight */}
      {upcoming.length > 0 && (
        <Card className="p-5 mb-6 bg-gradient-to-br from-primary-50 to-teal-50 border-primary-100">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary-600 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-xs text-primary-600 font-medium">Next Appointment</p>
                <p className="font-semibold text-navy-900">{upcoming[0].doctorName}</p>
                <p className="text-sm text-navy-600">{upcoming[0].doctorSpecialization} • {formatDate(upcoming[0].date)} at {upcoming[0].time}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={upcoming[0].status} />
              <Button size="sm" variant="outline" onClick={() => navigate('/patient/appointments')}>View Details</Button>
            </div>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming appointments */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Upcoming Appointments</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => navigate('/patient/appointments')}>View all</Button>
              </div>
            </CardHeader>
            <CardContent>
              {upcoming.length === 0 ? (
                <EmptyState icon={Calendar} title="No upcoming appointments" description="Book an appointment with a doctor today." action={<Button size="sm" onClick={() => navigate('/patient/doctors')}>Find Doctors</Button>} />
              ) : (
                <div className="space-y-3">
                  {upcoming.slice(0, 3).map((apt) => (
                    <AppointmentCard key={apt.id} appointment={apt} onView={() => navigate(`/patient/appointments/${apt.id}`)} onCancel={() => navigate('/patient/appointments')} onReschedule={() => navigate('/patient/appointments')} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick actions */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
            {[
              { label: 'Find Doctor', icon: Search, path: '/patient/doctors', color: 'primary' },
              { label: 'Appointments', icon: Calendar, path: '/patient/appointments', color: 'teal' },
              { label: 'Prescriptions', icon: FileText, path: '/patient/prescriptions', color: 'success' },
              { label: 'Medical History', icon: Activity, path: '/patient/medical-history', color: 'warning' },
            ].map((action) => (
              <button key={action.label} onClick={() => navigate(action.path)} className="card-hover p-4 text-center">
                <action.icon className="w-6 h-6 text-primary-600 mx-auto mb-2" />
                <p className="text-xs font-medium text-navy-700">{action.label}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Health tip */}
          <Card className="p-5 bg-gradient-to-br from-teal-50 to-primary-50 border-teal-100">
            <div className="flex items-center gap-2 mb-2">
              <HeartPulse className="w-5 h-5 text-teal-600" />
              <h3 className="font-semibold text-navy-900 text-sm">Health Tip of the Day</h3>
            </div>
            <p className="text-sm text-navy-600 leading-relaxed">Drink at least 8 glasses of water daily. Staying hydrated helps maintain energy levels and supports overall health.</p>
          </Card>

          {/* Recommended doctors */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recommended Doctors</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => navigate('/patient/doctors')}>View all</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {recommendedDoctors.map((doc) => (
                <div key={doc.id} className="flex items-center gap-3 p-2 hover:bg-navy-50 rounded-lg cursor-pointer" onClick={() => navigate(`/doctors/${doc.id}`)}>
                  <div className="w-10 h-10 rounded-lg bg-primary-50 text-primary-700 flex items-center justify-center text-sm font-semibold flex-shrink-0">{doc.name.replace('Dr. ', '').split(' ').map(n => n[0]).join('')}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-navy-900 truncate">{doc.name}</p>
                    <p className="text-xs text-navy-500">{doc.specializationName} • {doc.experienceYears} yrs</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-navy-400" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Recent notification */}
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Bell className="w-4 h-4 text-navy-400" />
              <h3 className="font-semibold text-navy-900 text-sm">Recent Activity</h3>
            </div>
            <div className="space-y-2">
              {past.slice(0, 3).map((apt) => (
                <div key={apt.id} className="flex items-start gap-2 text-xs text-navy-500">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary-400 mt-1.5" />
                  <p>Consultation with {apt.doctorName} on {formatDate(apt.date)}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
