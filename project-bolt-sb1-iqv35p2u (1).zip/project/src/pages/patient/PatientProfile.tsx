import { useState } from 'react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { useToast } from '@/context/ToastContext';
import { useAuth } from '@/context/AuthContext';
import { patients } from '@/data/patients';
import { LayoutDashboard, Search, CalendarDays, FileText, Activity, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/patient/dashboard', icon: LayoutDashboard },
  { label: 'Find Doctors', path: '/patient/doctors', icon: Search },
  { label: 'Appointments', path: '/patient/appointments', icon: CalendarDays },
  { label: 'Prescriptions', path: '/patient/prescriptions', icon: FileText },
  { label: 'Medical History', path: '/patient/medical-history', icon: Activity },
  { label: 'Profile', path: '/patient/profile', icon: User },
  { label: 'Settings', path: '/patient/settings', icon: Settings },
];

export function PatientProfile() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const patient = patients.find(p => p.email === user?.email) || patients[0];
  const [editing, setEditing] = useState(false);

  return (
    <DashboardLayout items={navItems} title="Patient Portal" headerTitle="My Profile" headerSubtitle="Manage your personal information" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="max-w-3xl mx-auto space-y-6">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <UserAvatar name={patient.name} size="lg" />
            <div>
              <h2 className="text-xl font-bold text-navy-900">{patient.name}</h2>
              <p className="text-sm text-navy-500">{patient.email}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="badge-success">Active</span>
                <span className="text-xs text-navy-400">Member since {new Date(patient.registeredDate).getFullYear()}</span>
              </div>
            </div>
            <div className="ml-auto">
              <Button variant={editing ? 'outline' : 'secondary'} size="sm" onClick={() => setEditing(!editing)}>{editing ? 'Cancel' : 'Edit Profile'}</Button>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input label="Full Name" defaultValue={patient.name} disabled={!editing} />
              <Input label="Email" defaultValue={patient.email} disabled={!editing} />
              <Input label="Phone" defaultValue={patient.phone} disabled={!editing} />
              <Input label="Date of Birth" defaultValue={patient.dateOfBirth} type="date" disabled={!editing} />
              <div>
                <label className="label">Gender</label>
                <select className="input" defaultValue={patient.gender} disabled={!editing}><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select>
              </div>
              <Input label="Blood Group" defaultValue={patient.bloodGroup} disabled={!editing} />
              <Input label="Address" defaultValue={patient.address} disabled={!editing} className="sm:col-span-2" />
              <Input label="City" defaultValue={patient.city} disabled={!editing} />
            </div>
            {editing && (
              <div className="flex justify-end gap-3 mt-6">
                <Button variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
                <Button onClick={() => { setEditing(false); showToast('success', 'Profile Updated', 'Your changes have been saved.'); }}>Save Changes</Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Medical Information</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-semibold text-navy-900 mb-2">Allergies</p>
                <div className="flex flex-wrap gap-2">
                  {patient.allergies.length > 0 ? patient.allergies.map((a, i) => <span key={i} className="badge-error">{a}</span>) : <span className="text-sm text-navy-400">No known allergies</span>}
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-navy-900 mb-2">Existing Conditions</p>
                <div className="flex flex-wrap gap-2">
                  {patient.conditions.length > 0 ? patient.conditions.map((c, i) => <span key={i} className="badge-warning">{c}</span>) : <span className="text-sm text-navy-400">No existing conditions</span>}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
