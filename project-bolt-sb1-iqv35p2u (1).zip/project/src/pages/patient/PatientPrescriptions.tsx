import { useNavigate, useParams } from 'react-router-dom';
import { FileText, Download, Share2, Printer, Pill, Stethoscope } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { prescriptions } from '@/data/medical';
import { formatDate, formatCurrency } from '@/lib/utils';
import { LayoutDashboard, Search, CalendarDays, FileText as FileTextIcon, Activity, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/patient/dashboard', icon: LayoutDashboard },
  { label: 'Find Doctors', path: '/patient/doctors', icon: Search },
  { label: 'Appointments', path: '/patient/appointments', icon: CalendarDays },
  { label: 'Prescriptions', path: '/patient/prescriptions', icon: FileTextIcon },
  { label: 'Medical History', path: '/patient/medical-history', icon: Activity },
  { label: 'Profile', path: '/patient/profile', icon: User },
  { label: 'Settings', path: '/patient/settings', icon: Settings },
];

export function PatientPrescriptions() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const patientPrescriptions = prescriptions.filter(p => p.patientId === 'p1');

  return (
    <DashboardLayout items={navItems} title="Patient Portal" headerTitle="My Prescriptions" headerSubtitle="View and download your prescriptions" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      {patientPrescriptions.length === 0 ? (
        <Card><EmptyState icon={FileText} title="No prescriptions yet" description="Your prescriptions will appear here after consultations." /></Card>
      ) : (
        <div className="space-y-4">
          {patientPrescriptions.map((rx) => (
            <Card key={rx.id} className="overflow-hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-5 border-b border-navy-50">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center"><Stethoscope className="w-6 h-6 text-primary-600" /></div>
                  <div>
                    <p className="font-semibold text-navy-900">{rx.doctorName}</p>
                    <p className="text-xs text-navy-500">{formatDate(rx.date)} • {rx.diagnosis}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-navy-500">{rx.medicines.length} medicines</span>
                  <Button variant="outline" size="sm" onClick={() => navigate(`/patient/prescriptions/${rx.id}`)}>View</Button>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                  <div><p className="text-xs text-navy-400">Diagnosis</p><p className="font-medium text-navy-700">{rx.diagnosis}</p></div>
                  <div><p className="text-xs text-navy-400">Symptoms</p><p className="font-medium text-navy-700">{rx.symptoms.join(', ')}</p></div>
                  <div><p className="text-xs text-navy-400">Follow-up</p><p className="font-medium text-navy-700">{rx.followUpDate ? formatDate(rx.followUpDate) : 'Not required'}</p></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}

export function PrescriptionDetail() {
  const { id } = useParams();
  const { showToast } = useToast();
  const prescription = prescriptions.find(p => p.id === id);

  if (!prescription) {
    return <div className="min-h-screen flex items-center justify-center"><p>Prescription not found</p></div>;
  }

  return (
    <DashboardLayout items={navItems} title="Patient Portal" headerTitle="Prescription Details" headerSubtitle={`Prescription #${prescription.id.toUpperCase()}`} footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="max-w-3xl mx-auto">
        <Card className="overflow-hidden">
          {/* Header */}
          <div className="bg-primary-600 p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Stethoscope className="w-7 h-7" />
                <span className="text-lg font-bold">CareConnect</span>
              </div>
              <p className="text-sm text-primary-100">Prescription</p>
            </div>
          </div>

          <CardContent className="p-6 space-y-6">
            {/* Doctor & Patient info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-4 border-b border-navy-100">
              <div>
                <p className="text-xs text-navy-400 font-medium">Doctor</p>
                <p className="font-semibold text-navy-900 mt-0.5">{prescription.doctorName}</p>
              </div>
              <div>
                <p className="text-xs text-navy-400 font-medium">Patient</p>
                <p className="font-semibold text-navy-900 mt-0.5">{prescription.patientName}</p>
              </div>
              <div>
                <p className="text-xs text-navy-400 font-medium">Date</p>
                <p className="font-medium text-navy-700 mt-0.5">{formatDate(prescription.date)}</p>
              </div>
              <div>
                <p className="text-xs text-navy-400 font-medium">Diagnosis</p>
                <p className="font-medium text-navy-700 mt-0.5">{prescription.diagnosis}</p>
              </div>
            </div>

            {/* Vitals */}
            {prescription.vitals && (
              <div>
                <h3 className="text-sm font-semibold text-navy-900 mb-2">Vitals</h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {Object.entries(prescription.vitals).map(([key, value]) => (
                    <div key={key} className="p-2 bg-navy-50 rounded-lg">
                      <p className="text-[10px] text-navy-400 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                      <p className="text-xs font-medium text-navy-700 mt-0.5">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Symptoms */}
            <div>
              <h3 className="text-sm font-semibold text-navy-900 mb-2">Symptoms</h3>
              <div className="flex flex-wrap gap-2">
                {prescription.symptoms.map((s, i) => <span key={i} className="badge-warning">{s}</span>)}
              </div>
            </div>

            {/* Medicines table */}
            <div>
              <h3 className="text-sm font-semibold text-navy-900 mb-2 flex items-center gap-1.5"><Pill className="w-4 h-4 text-primary-600" /> Medicines</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-xs text-navy-400 border-b border-navy-100">
                      <th className="text-left py-2 font-medium">Medicine</th>
                      <th className="text-left py-2 font-medium">Dosage</th>
                      <th className="text-left py-2 font-medium">Frequency</th>
                      <th className="text-left py-2 font-medium">Duration</th>
                      <th className="text-left py-2 font-medium hidden sm:table-cell">Instructions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {prescription.medicines.map((med, i) => (
                      <tr key={i} className="border-b border-navy-50">
                        <td className="py-3 font-medium text-navy-900">{med.name}</td>
                        <td className="py-3 text-navy-600">{med.dosage}</td>
                        <td className="py-3 text-navy-600">{med.frequency}</td>
                        <td className="py-3 text-navy-600">{med.duration}</td>
                        <td className="py-3 text-navy-500 hidden sm:table-cell">{med.instructions}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Advice */}
            {prescription.advice && (
              <div>
                <h3 className="text-sm font-semibold text-navy-900 mb-2">Advice</h3>
                <p className="text-sm text-navy-600 leading-relaxed p-3 bg-navy-50 rounded-lg">{prescription.advice}</p>
              </div>
            )}

            {/* Follow-up */}
            {prescription.followUpDate && (
              <div className="flex items-center gap-2 p-3 bg-primary-50 rounded-lg">
                <p className="text-sm text-primary-700">Follow-up recommended on <span className="font-semibold">{formatDate(prescription.followUpDate)}</span></p>
              </div>
            )}

            {/* Signature */}
            <div className="pt-4 border-t border-navy-100">
              <div className="flex justify-end">
                <div className="text-center">
                  <p className="text-sm font-semibold text-navy-900 italic">{prescription.doctorName}</p>
                  <p className="text-xs text-navy-400">Digital Signature</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 mt-6">
          <Button variant="outline" className="flex-1" onClick={() => showToast('success', 'Downloaded', 'Prescription PDF downloaded.')}><Download className="w-4 h-4" /> Download PDF</Button>
          <Button variant="outline" className="flex-1" onClick={() => window.print()}><Printer className="w-4 h-4" /> Print</Button>
          <Button variant="outline" className="flex-1" onClick={() => showToast('success', 'Shared', 'Prescription link copied to clipboard.')}><Share2 className="w-4 h-4" /> Share</Button>
        </div>
      </div>
    </DashboardLayout>
  );
}
