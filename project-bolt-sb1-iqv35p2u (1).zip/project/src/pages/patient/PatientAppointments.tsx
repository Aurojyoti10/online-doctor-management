import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, X } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent } from '@/components/ui/Card';
import { AppointmentCard } from '@/components/shared/AppointmentCard';
import { EmptyState } from '@/components/ui/States';
import { ConfirmDialog } from '@/components/ui/Modal';
import { useToast } from '@/context/ToastContext';
import { appointments } from '@/data/appointments';
import { LayoutDashboard, Search, CalendarDays, FileText, Activity, User, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/patient/dashboard', icon: LayoutDashboard },
  { label: 'Find Doctors', path: '/patient/doctors', icon: Search },
  { label: 'Appointments', path: '/patient/appointments', icon: CalendarDays },
  { label: 'Prescriptions', path: '/patient/prescriptions', icon: FileText },
  { label: 'Medical History', path: '/patient/medical-history', icon: Activity },
  { label: 'Profile', path: '/patient/profile', icon: User },
  { label: 'Settings', path: '/patient/settings', icon: Settings },
];

const tabs = ['Upcoming', 'Completed', 'Cancelled'] as const;

export function PatientAppointments() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<typeof tabs[number]>('Upcoming');
  const [cancelTarget, setCancelTarget] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [localAppointments, setLocalAppointments] = useState(appointments);

  const patientAppointments = localAppointments.filter(a => a.patientId === 'p1');

  const filtered = patientAppointments.filter(a => {
    if (activeTab === 'Upcoming') return a.status === 'confirmed' || a.status === 'pending';
    if (activeTab === 'Completed') return a.status === 'completed';
    if (activeTab === 'Cancelled') return a.status === 'cancelled' || a.status === 'rejected';
    return true;
  });

  const handleCancel = () => {
    setLocalAppointments(prev => prev.map(a => a.id === cancelTarget ? { ...a, status: 'cancelled' as const, paymentStatus: 'refunded' as const } : a));
    showToast('success', 'Appointment Cancelled', 'Your appointment has been cancelled. Refund will be processed.');
    setCancelTarget(null);
    setCancelReason('');
  };

  return (
    <DashboardLayout items={navItems} title="Patient Portal" headerTitle="My Appointments" headerSubtitle="View and manage your appointments" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-white border border-navy-100 rounded-xl mb-6 w-full sm:w-auto sm:inline-flex">
        {tabs.map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 sm:flex-none px-4 py-2 text-sm font-medium rounded-lg transition-colors ${activeTab === tab ? 'bg-primary-50 text-primary-700' : 'text-navy-500 hover:text-navy-700'}`}>
            {tab} <span className="ml-1 text-xs text-navy-400">({patientAppointments.filter(a => tab === 'Upcoming' ? a.status === 'confirmed' || a.status === 'pending' : tab === 'Completed' ? a.status === 'completed' : a.status === 'cancelled' || a.status === 'rejected').length})</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={Calendar}
            title={activeTab === 'Upcoming' ? 'No upcoming appointments' : activeTab === 'Completed' ? 'No completed appointments' : 'No cancelled appointments'}
            description={activeTab === 'Upcoming' ? 'Book an appointment with a doctor today.' : 'Your appointment history will appear here.'}
            action={activeTab === 'Upcoming' ? <button className="btn-primary" onClick={() => navigate('/patient/doctors')}>Find Doctors</button> : undefined}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((apt) => (
            <AppointmentCard
              key={apt.id}
              appointment={apt}
              onView={() => navigate(`/patient/appointments/${apt.id}`)}
              onReschedule={() => showToast('info', 'Reschedule', 'Reschedule feature will open the booking flow.')}
              onCancel={() => setCancelTarget(apt.id)}
              onRate={() => showToast('success', 'Thank you!', 'Rating submitted successfully.')}
            />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!cancelTarget}
        onClose={() => { setCancelTarget(null); setCancelReason(''); }}
        onConfirm={handleCancel}
        title="Cancel Appointment?"
        description="Are you sure you want to cancel this appointment? A full refund will be processed to your original payment method."
        confirmLabel="Yes, Cancel Appointment"
      />
    </DashboardLayout>
  );
}
