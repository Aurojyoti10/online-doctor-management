import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Stethoscope, User, Mail, Phone, Lock, Calendar, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { cn } from '@/lib/utils';

const registerSchema = z.object({
  fullName: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().min(10, 'Enter a valid phone number'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string(),
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  gender: z.enum(['male', 'female', 'other'], { message: 'Select a gender' }),
}).refine((data) => data.password === data.confirmPassword, { message: 'Passwords do not match', path: ['confirmPassword'] });

type RegisterFormData = z.infer<typeof registerSchema>;

export function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register: registerUser } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors } } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: '', email: '', phone: '', password: '', confirmPassword: '', dateOfBirth: '', gender: undefined },
  });

  const onSubmit = async (data: RegisterFormData) => {
    setLoading(true);
    const result = await registerUser({ name: data.fullName, email: data.email, phone: data.phone, password: data.password });
    setLoading(false);
    if (result.success) {
      showToast('success', 'Account Created', 'Welcome to CareConnect!');
      navigate('/patient/dashboard');
    } else {
      showToast('error', 'Registration Failed', result.error);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-teal-500 to-teal-700 p-12 flex-col justify-between">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">CareConnect</span>
          </div>
          <h2 className="text-3xl font-bold text-white mt-12 leading-tight">
            Join thousands of patients<br />managing their health online
          </h2>
          <p className="text-teal-100 mt-4 max-w-md">
            Create your free account and get access to verified doctors, easy appointment booking, and digital health records.
          </p>
        </div>
        <div className="space-y-3 text-teal-100 text-sm">
          <div className="flex items-center gap-2">✓ Book appointments with verified doctors</div>
          <div className="flex items-center gap-2">✓ Access your medical history anytime</div>
          <div className="flex items-center gap-2">✓ Get digital prescriptions instantly</div>
          <div className="flex items-center gap-2">✓ Online and in-person consultations</div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 bg-navy-50 overflow-y-auto">
        <div className="w-full max-w-md py-8">
          <div className="lg:hidden flex items-center gap-2.5 mb-6">
            <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-navy-900">CareConnect</span>
          </div>

          <div className="card p-6 sm:p-8">
            <h1 className="text-2xl font-bold text-navy-900">Create Account</h1>
            <p className="text-sm text-navy-500 mt-1">Register to start booking appointments</p>

            <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
              <div>
                <label className="label">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                  <input {...register('fullName')} placeholder="Enter your full name" className={cn('input pl-10', errors.fullName && 'border-error-500')} />
                </div>
                {errors.fullName && <p className="mt-1 text-xs text-error-600">{errors.fullName.message}</p>}
              </div>

              <div>
                <label className="label">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                  <input {...register('email')} type="email" placeholder="you@example.com" className={cn('input pl-10', errors.email && 'border-error-500')} />
                </div>
                {errors.email && <p className="mt-1 text-xs text-error-600">{errors.email.message}</p>}
              </div>

              <div>
                <label className="label">Phone</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                  <input {...register('phone')} type="tel" placeholder="+91 98765 43210" className={cn('input pl-10', errors.phone && 'border-error-500')} />
                </div>
                {errors.phone && <p className="mt-1 text-xs text-error-600">{errors.phone.message}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Date of Birth</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                    <input {...register('dateOfBirth')} type="date" className={cn('input pl-10', errors.dateOfBirth && 'border-error-500')} />
                  </div>
                  {errors.dateOfBirth && <p className="mt-1 text-xs text-error-600">{errors.dateOfBirth.message}</p>}
                </div>
                <div>
                  <label className="label">Gender</label>
                  <select {...register('gender')} className={cn('input', errors.gender && 'border-error-500')}>
                    <option value="">Select</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                  {errors.gender && <p className="mt-1 text-xs text-error-600">{errors.gender.message}</p>}
                </div>
              </div>

              <div>
                <label className="label">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                  <input {...register('password')} type={showPassword ? 'text' : 'password'} placeholder="Create a password" className={cn('input pl-10 pr-10', errors.password && 'border-error-500')} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 hover:text-navy-600">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-xs text-error-600">{errors.password.message}</p>}
              </div>

              <div>
                <label className="label">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                  <input {...register('confirmPassword')} type={showPassword ? 'text' : 'password'} placeholder="Re-enter password" className={cn('input pl-10', errors.confirmPassword && 'border-error-500')} />
                </div>
                {errors.confirmPassword && <p className="mt-1 text-xs text-error-600">{errors.confirmPassword.message}</p>}
              </div>

              <Button type="submit" size="lg" className="w-full" loading={loading}>Create Account</Button>
            </form>

            <p className="text-center text-sm text-navy-600 mt-6">
              Already have an account? <button onClick={() => navigate('/login')} className="text-primary-600 font-semibold hover:text-primary-700">Login</button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
