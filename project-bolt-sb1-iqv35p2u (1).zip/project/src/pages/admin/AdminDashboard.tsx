import { useState } from 'react';
import { Users, Calendar, IndianRupee, Clock, TrendingUp } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { StatCard } from '@/components/shared/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { doctors } from '@/data/doctors';
import { patients } from '@/data/patients';
import { appointments } from '@/data/appointments';
import { formatCurrency } from '@/lib/utils';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { LayoutDashboard, Stethoscope, Users as UsersIcon, CalendarDays, IndianRupee as Rupee, Star, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: Stethoscope },
  { label: 'Patients', path: '/admin/patients', icon: UsersIcon },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: Calendar },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

const appointmentTrend = [
  { date: 'Sep 1', appointments: 12 }, { date: 'Sep 2', appointments: 15 }, { date: 'Sep 3', appointments: 18 },
  { date: 'Sep 4', appointments: 14 }, { date: 'Sep 5', appointments: 22 }, { date: 'Sep 6', appointments: 25 },
  { date: 'Sep 7', appointments: 20 }, { date: 'Sep 8', appointments: 28 },
];

const patientGrowth = [
  { month: 'Apr', patients: 1200 }, { month: 'May', patients: 1450 }, { month: 'Jun', patients: 1800 },
  { month: 'Jul', patients: 2100 }, { month: 'Aug', patients: 2500 }, { month: 'Sep', patients: 2800 },
];

const statusDistribution = [
  { name: 'Confirmed', value: 18, color: '#22c55e' },
  { name: 'Pending', value: 8, color: '#f59e0b' },
  { name: 'Completed', value: 12, color: '#2563eb' },
  { name: 'Cancelled', value: 5, color: '#ef4444' },
];

const specPopularity = [
  { name: 'General Physician', count: 45 }, { name: 'Cardiologist', count: 32 }, { name: 'Dermatologist', count: 28 },
  { name: 'Pediatrician', count: 24 }, { name: 'Orthopedic', count: 20 }, { name: 'Gynecologist', count: 18 },
];

export function AdminDashboard() {
  const totalRevenue = appointments.filter(a => a.paymentStatus === 'paid').reduce((s, a) => s + a.fee, 0);
  const todayAppointments = appointments.filter(a => a.date === '2026-09-09').length;
  const pendingRequests = appointments.filter(a => a.status === 'pending').length;

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="Dashboard" headerSubtitle="Platform overview and statistics" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        <StatCard label="Total Doctors" value={doctors.length} icon={Stethoscope} color="primary" />
        <StatCard label="Total Patients" value={patients.length} icon={Users} color="teal" />
        <StatCard label="Total Appointments" value={appointments.length} icon={Calendar} color="success" />
        <StatCard label="Today's Appts" value={todayAppointments} icon={Clock} color="warning" />
        <StatCard label="Revenue" value={formatCurrency(totalRevenue)} icon={IndianRupee} color="primary" trend={{ value: "+15%", up: true }} />
        <StatCard label="Pending Requests" value={pendingRequests} icon={TrendingUp} color="error" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Appointments Over Time</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={appointmentTrend}>
                <defs>
                  <linearGradient id="colorAppt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} /><stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Area type="monotone" dataKey="appointments" stroke="#2563eb" strokeWidth={2} fill="url(#colorAppt)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Appointment Status</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={statusDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} innerRadius={45}>
                  {statusDistribution.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Patient Growth</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={patientGrowth}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Line type="monotone" dataKey="patients" stroke="#14b8a6" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Specialization Popularity</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={specPopularity} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={100} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Bar dataKey="count" fill="#2563eb" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
