import { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card } from '@/components/ui/Card';
import { StatusBadge } from '@/components/ui/Badge';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { EmptyState } from '@/components/ui/States';
import { appointments as initialAppts } from '@/data/appointments';
import { doctors } from '@/data/doctors';
import { formatDate, formatCurrency } from '@/lib/utils';
import { CalendarDays } from 'lucide-react';
import { LayoutDashboard, Stethoscope, Users, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: Stethoscope },
  { label: 'Patients', path: '/admin/patients', icon: Users },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: CalendarDays },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

export function AdminAppointments() {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterDoctor, setFilterDoctor] = useState('');
  const [sortOpen, setSortOpen] = useState(false);

  const filtered = initialAppts.filter(a =>
    (a.patientName.toLowerCase().includes(search.toLowerCase()) || a.doctorName.toLowerCase().includes(search.toLowerCase()) || a.id.toLowerCase().includes(search.toLowerCase())) &&
    (!filterStatus || a.status === filterStatus) &&
    (!filterDoctor || a.doctorId === filterDoctor)
  );

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="All Appointments" headerSubtitle={`${initialAppts.length} total appointments`} footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
          <input type="text" placeholder="Search by patient, doctor, or ID..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
        </div>
        <select className="input sm:w-44" value={filterDoctor} onChange={(e) => setFilterDoctor(e.target.value)}>
          <option value="">All Doctors</option>
          {doctors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
        <select className="input sm:w-40" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
          <option value="">All Status</option>
          <option value="confirmed">Confirmed</option>
          <option value="pending">Pending</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-navy-50 text-xs text-navy-500">
              <tr>
                <th className="text-left px-4 py-3 font-medium">ID</th>
                <th className="text-left px-4 py-3 font-medium">Patient</th>
                <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Doctor</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Date/Time</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Type</th>
                <th className="text-left px-4 py-3 font-medium">Status</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Payment</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Fee</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((apt) => (
                <tr key={apt.id} className="border-b border-navy-50 hover:bg-navy-50/50">
                  <td className="px-4 py-3 text-xs font-mono text-navy-500">{apt.id.toUpperCase()}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <UserAvatar name={apt.patientName} size="xs" />
                      <span className="font-medium text-navy-900">{apt.patientName}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-navy-600 hidden md:table-cell">{apt.doctorName}</td>
                  <td className="px-4 py-3 text-navy-600 text-xs hidden lg:table-cell">{formatDate(apt.date)} • {apt.time}</td>
                  <td className="px-4 py-3 hidden sm:table-cell"><StatusBadge status={apt.consultationType} /></td>
                  <td className="px-4 py-3"><StatusBadge status={apt.status} /></td>
                  <td className="px-4 py-3 hidden lg:table-cell"><StatusBadge status={apt.paymentStatus} /></td>
                  <td className="px-4 py-3 text-navy-600 hidden lg:table-cell">{formatCurrency(apt.fee)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <EmptyState icon={CalendarDays} title="No appointments found" description="Try adjusting your filters." />}
      </Card>
    </DashboardLayout>
  );
}
