import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { StatCard } from '@/components/shared/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { appointments } from '@/data/appointments';
import { doctors } from '@/data/doctors';
import { patients } from '@/data/patients';
import { specializations } from '@/data/specializations';
import { formatCurrency } from '@/lib/utils';
import { Calendar, Users, Stethoscope, IndianRupee, TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { LayoutDashboard, Stethoscope as StethoscopeIcon, Users as UsersIcon, CalendarDays, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: StethoscopeIcon },
  { label: 'Patients', path: '/admin/patients', icon: UsersIcon },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: CalendarDays },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

const dailyAppts = [
  { date: 'Sep 1', bookings: 12, completed: 10 }, { date: 'Sep 2', bookings: 15, completed: 13 },
  { date: 'Sep 3', bookings: 18, completed: 15 }, { date: 'Sep 4', bookings: 14, completed: 12 },
  { date: 'Sep 5', bookings: 22, completed: 19 }, { date: 'Sep 6', bookings: 25, completed: 22 },
  { date: 'Sep 7', bookings: 20, completed: 17 }, { date: 'Sep 8', bookings: 28, completed: 24 },
];

const monthlyRevenue = [
  { month: 'Apr', revenue: 120000 }, { month: 'May', revenue: 145000 }, { month: 'Jun', revenue: 168000 },
  { month: 'Jul', revenue: 155000 }, { month: 'Aug', revenue: 182000 }, { month: 'Sep', revenue: 195000 },
];

const topSpecs = [
  { name: 'General Physician', count: 45 }, { name: 'Cardiologist', count: 32 }, { name: 'Dermatologist', count: 28 },
  { name: 'Pediatrician', count: 24 }, { name: 'Orthopedic', count: 20 }, { name: 'Gynecologist', count: 18 },
];

const topDoctors = [
  { name: 'Dr. Rajesh Kumar', patients: 412 }, { name: 'Dr. Sarah Wilson', patients: 234 },
  { name: 'Dr. Sunita Joshi', patients: 389 }, { name: 'Dr. Anjali Mehta', patients: 356 },
  { name: 'Dr. Lakshmi Iyer', patients: 421 },
];

const statusPie = [
  { name: 'Completed', value: 12, color: '#2563eb' }, { name: 'Confirmed', value: 18, color: '#22c55e' },
  { name: 'Pending', value: 8, color: '#f59e0b' }, { name: 'Cancelled', value: 5, color: '#ef4444' },
];

export function AdminAnalytics() {
  const totalRevenue = monthlyRevenue.reduce((s, d) => s + d.revenue, 0);
  const completedRate = Math.round((appointments.filter(a => a.status === 'completed').length / appointments.length) * 100);
  const cancelRate = Math.round((appointments.filter(a => a.status === 'cancelled').length / appointments.length) * 100);
  const avgFee = Math.round(appointments.reduce((s, a) => s + a.fee, 0) / appointments.length);

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="Analytics" headerSubtitle="Platform performance and insights" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Bookings" value={appointments.length} icon={Calendar} color="primary" trend={{ value: "+22%", up: true }} />
        <StatCard label="Completed Rate" value={`${completedRate}%`} icon={Activity} color="success" trend={{ value: "+5%", up: true }} />
        <StatCard label="Cancellation Rate" value={`${cancelRate}%`} icon={TrendingDown} color="error" trend={{ value: "-2%", up: true }} />
        <StatCard label="Avg Consultation Fee" value={formatCurrency(avgFee)} icon={IndianRupee} color="teal" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader><CardTitle>Daily Appointments</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={dailyAppts}>
                <defs>
                  <linearGradient id="colorBookings" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} /><stop offset="95%" stopColor="#2563eb" stopOpacity={0} /></linearGradient>
                  <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#22c55e" stopOpacity={0.2} /><stop offset="95%" stopColor="#22c55e" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Area type="monotone" dataKey="bookings" stroke="#2563eb" strokeWidth={2} fill="url(#colorBookings)" />
                <Area type="monotone" dataKey="completed" stroke="#22c55e" strokeWidth={2} fill="url(#colorCompleted)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Monthly Revenue</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip formatter={(v: any) => [formatCurrency(Number(v)), 'Revenue']} contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Bar dataKey="revenue" fill="#2563eb" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Top Specializations</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={topSpecs} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={100} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Bar dataKey="count" fill="#14b8a6" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Top Doctors by Patients</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={topDoctors} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 9, fill: '#94a3b8' }} axisLine={false} tickLine={false} width={110} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Bar dataKey="patients" fill="#2563eb" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Appointment Status Distribution</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={statusPie} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} innerRadius={45}>
                  {statusPie.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Patient & Doctor Growth</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={[
                { month: 'Apr', patients: 1200, doctors: 850 }, { month: 'May', patients: 1450, doctors: 920 },
                { month: 'Jun', patients: 1800, doctors: 1050 }, { month: 'Jul', patients: 2100, doctors: 1120 },
                { month: 'Aug', patients: 2500, doctors: 1180 }, { month: 'Sep', patients: 2800, doctors: 1200 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '12px' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
                <Line type="monotone" dataKey="patients" stroke="#2563eb" strokeWidth={2} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="doctors" stroke="#14b8a6" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
