import { useState } from 'react';
import { Calendar, Clock, Edit2 } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/ui/Badge';
import { useToast } from '@/context/ToastContext';
import { doctors } from '@/data/doctors';
import { cn } from '@/lib/utils';
import { LayoutDashboard, Stethoscope, Users, CalendarDays, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: Stethoscope },
  { label: 'Patients', path: '/admin/patients', icon: Users },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: CalendarDays },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const fullDays: Record<string, string> = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' };

export function AdminSchedules() {
  const { showToast } = useToast();
  const [selectedDoctorId, setSelectedDoctorId] = useState(doctors[0].id);
  const [editDay, setEditDay] = useState<string | null>(null);
  const doctor = doctors.find(d => d.id === selectedDoctorId)!;

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="Schedules" headerSubtitle="View and manage doctor schedules" footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="mb-6 max-w-xs">
        <Select label="Select Doctor" value={selectedDoctorId} onChange={(e) => setSelectedDoctorId(e.target.value)}>
          {doctors.map(d => <option key={d.id} value={d.id}>{d.name} — {d.specializationName}</option>)}
        </Select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Weekly Schedule — {doctor.name}</CardTitle>
              <Badge variant={doctor.onlineConsultation ? 'teal' : 'navy'}>{doctor.onlineConsultation ? 'Online Available' : 'In-person Only'}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {doctor.availability.map((day) => (
              <div key={day.day} className={cn('flex items-center justify-between p-3 rounded-lg border', day.enabled ? 'border-navy-100' : 'border-navy-50 bg-navy-50/50')}>
                <div className="flex items-center gap-3">
                  <div className="w-12 text-sm font-semibold text-navy-900">{day.day}</div>
                  <div>
                    {day.enabled ? (
                      <div className="flex flex-wrap gap-1.5">
                        {day.ranges.map((r, i) => <span key={i} className="badge-primary text-[10px]">{r.start} - {r.end}</span>)}
                      </div>
                    ) : <span className="text-xs text-error-500">Unavailable</span>}
                  </div>
                </div>
                {day.enabled && <Button variant="ghost" size="sm" onClick={() => setEditDay(day.day)}><Edit2 className="w-3.5 h-3.5" /> Edit</Button>}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Schedule Info</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg">
              <Calendar className="w-5 h-5 text-primary-600" />
              <div><p className="text-sm font-medium text-navy-900">Working Days</p><p className="text-xs text-navy-500">{doctor.availability.filter(d => d.enabled).length} days per week</p></div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-navy-50 rounded-lg">
              <Clock className="w-5 h-5 text-teal-600" />
              <div><p className="text-sm font-medium text-navy-900">Consultation Fee</p><p className="text-xs text-navy-500">₹{doctor.consultationFee}</p></div>
            </div>
            <div className="p-3 bg-navy-50 rounded-lg">
              <p className="text-sm font-medium text-navy-900">Hospital</p>
              <p className="text-xs text-navy-500">{doctor.hospital}, {doctor.city}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Modal open={!!editDay} onClose={() => setEditDay(null)} title={`Edit ${editDay ? fullDays[editDay] : ''} Schedule`}>
        <div className="p-5">
          <p className="text-sm text-navy-500 mb-4">Adjust time slots for this day.</p>
          {editDay && doctor.availability.find(d => d.day === editDay)?.ranges.map((r, i) => (
            <div key={i} className="flex items-center gap-2 mb-2">
              <input type="time" defaultValue={r.start} className="input flex-1" />
              <span className="text-navy-400">to</span>
              <input type="time" defaultValue={r.end} className="input flex-1" />
            </div>
          ))}
          <div className="flex gap-2 mt-5">
            <Button variant="outline" className="flex-1" onClick={() => setEditDay(null)}>Cancel</Button>
            <Button className="flex-1" onClick={() => { setEditDay(null); showToast('success', 'Schedule Updated', 'Doctor schedule has been modified.'); }}>Save</Button>
          </div>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
