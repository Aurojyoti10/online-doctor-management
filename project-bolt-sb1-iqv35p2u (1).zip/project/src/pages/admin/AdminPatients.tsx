import { useState } from 'react';
import { Search, MoreVertical, Eye, Edit2, Trash2, Ban, Users } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StatusBadge } from '@/components/ui/Badge';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { EmptyState } from '@/components/ui/States';
import { ConfirmDialog } from '@/components/ui/Modal';
import { useToast } from '@/context/ToastContext';
import { patients as initialPatients } from '@/data/patients';
import { formatDate } from '@/lib/utils';
import { LayoutDashboard, Stethoscope, Users as UsersIcon, CalendarDays, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: Stethoscope },
  { label: 'Patients', path: '/admin/patients', icon: UsersIcon },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: CalendarDays },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

export function AdminPatients() {
  const { showToast } = useToast();
  const [patients, setPatients] = useState(initialPatients);
  const [search, setSearch] = useState('');
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.email.toLowerCase().includes(search.toLowerCase()));

  const toggleSuspend = (id: string) => {
    setPatients(prev => prev.map(p => p.id === id ? { ...p, status: p.status === 'active' ? 'suspended' : 'active' } : p));
    setOpenMenu(null);
    showToast('success', 'Status Updated', 'Patient status has been changed.');
  };

  const handleDelete = () => {
    setPatients(prev => prev.filter(p => p.id !== deleteTarget));
    showToast('success', 'Patient Removed', 'The patient has been removed.');
    setDeleteTarget(null);
  };

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="Manage Patients" headerSubtitle={`${patients.length} patients registered`} footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
          <input type="text" placeholder="Search patients..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-navy-50 text-xs text-navy-500">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Patient</th>
                <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Age/Gender</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Appointments</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Status</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Registered</th>
                <th className="text-right px-4 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-b border-navy-50 hover:bg-navy-50/50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <UserAvatar name={p.name} size="sm" />
                      <div><p className="font-medium text-navy-900">{p.name}</p><p className="text-xs text-navy-400">{p.email}</p></div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-navy-600 hidden md:table-cell">{p.age} / {p.gender}</td>
                  <td className="px-4 py-3 text-navy-600 hidden lg:table-cell">{p.appointmentsCount}</td>
                  <td className="px-4 py-3 hidden sm:table-cell"><StatusBadge status={p.status === 'active' ? 'active' : 'cancelled'} /></td>
                  <td className="px-4 py-3 text-navy-500 text-xs hidden lg:table-cell">{formatDate(p.registeredDate)}</td>
                  <td className="px-4 py-3 text-right relative">
                    <button onClick={() => setOpenMenu(openMenu === p.id ? null : p.id)} className="p-1.5 text-navy-400 hover:text-navy-700 hover:bg-navy-100 rounded-lg"><MoreVertical className="w-4 h-4" /></button>
                    {openMenu === p.id && (
                      <div className="absolute right-4 top-full mt-1 w-40 bg-white rounded-xl shadow-elevated border border-navy-100 py-1 z-10 text-left">
                        <button onClick={() => { setOpenMenu(null); showToast('info', 'View Profile', 'Patient profile page will open.'); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50"><Eye className="w-4 h-4" /> View</button>
                        <button onClick={() => { setOpenMenu(null); showToast('info', 'Edit', 'Edit form will open.'); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50"><Edit2 className="w-4 h-4" /> Edit</button>
                        <button onClick={() => toggleSuspend(p.id)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50"><Ban className="w-4 h-4" /> {p.status === 'active' ? 'Suspend' : 'Reactivate'}</button>
                        <button onClick={() => { setDeleteTarget(p.id); setOpenMenu(null); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-error-600 hover:bg-error-50"><Trash2 className="w-4 h-4" /> Delete</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <EmptyState icon={Users} title="No patients found" description="No patients match your search." />}
      </Card>

      <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Delete Patient?" description="Are you sure you want to permanently delete this patient? This action cannot be undone." confirmLabel="Yes, Delete" />
    </DashboardLayout>
  );
}
