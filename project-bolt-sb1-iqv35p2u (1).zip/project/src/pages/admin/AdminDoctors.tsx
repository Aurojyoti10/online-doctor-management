import { useState } from 'react';
import { Search, MoreVertical, Eye, Edit2, Trash2, UserCheck, UserX, Plus } from 'lucide-react';
import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal, ConfirmDialog } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/Badge';
import { UserAvatar } from '@/components/shared/UserAvatar';
import { useToast } from '@/context/ToastContext';
import { doctors as initialDoctors } from '@/data/doctors';
import { specializations } from '@/data/specializations';
import { formatDate, formatCurrency } from '@/lib/utils';
import { LayoutDashboard, Stethoscope, Users, CalendarDays, FileText, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Doctors', path: '/admin/doctors', icon: Stethoscope },
  { label: 'Patients', path: '/admin/patients', icon: Users },
  { label: 'Specializations', path: '/admin/specializations', icon: FileText },
  { label: 'Schedules', path: '/admin/schedules', icon: CalendarDays },
  { label: 'Appointments', path: '/admin/appointments', icon: CalendarDays },
  { label: 'Analytics', path: '/admin/analytics', icon: BarChart3 },
  { label: 'Settings', path: '/admin/settings', icon: Settings },
];

export function AdminDoctors() {
  const { showToast } = useToast();
  const [doctors, setDoctors] = useState(initialDoctors);
  const [search, setSearch] = useState('');
  const [filterSpec, setFilterSpec] = useState('');
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const filtered = doctors.filter(d =>
    (d.name.toLowerCase().includes(search.toLowerCase()) || d.email.toLowerCase().includes(search.toLowerCase())) &&
    (!filterSpec || d.specializationId === filterSpec)
  );

  const toggleStatus = (id: string) => {
    setDoctors(prev => prev.map(d => d.id === id ? { ...d, status: d.status === 'active' ? 'inactive' : 'active' } : d));
    setOpenMenu(null);
    showToast('success', 'Status Updated', 'Doctor status has been changed.');
  };

  const handleDelete = () => {
    setDoctors(prev => prev.filter(d => d.id !== deleteTarget));
    showToast('success', 'Doctor Removed', 'The doctor has been removed from the platform.');
    setDeleteTarget(null);
  };

  return (
    <DashboardLayout items={navItems} title="Admin Portal" headerTitle="Manage Doctors" headerSubtitle={`${doctors.length} doctors registered`} footerItem={{ label: 'Logout', path: '/login', icon: LogOut }}>
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
          <input type="text" placeholder="Search doctors..." value={search} onChange={(e) => setSearch(e.target.value)} className="input pl-10" />
        </div>
        <select className="input sm:w-48" value={filterSpec} onChange={(e) => setFilterSpec(e.target.value)}>
          <option value="">All Specializations</option>
          {specializations.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <Button onClick={() => setShowAddModal(true)}><Plus className="w-4 h-4" /> Add Doctor</Button>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-navy-50 text-xs text-navy-500">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Doctor</th>
                <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Specialization</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Experience</th>
                <th className="text-left px-4 py-3 font-medium hidden lg:table-cell">Fee</th>
                <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Status</th>
                <th className="text-right px-4 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((doc) => (
                <tr key={doc.id} className="border-b border-navy-50 hover:bg-navy-50/50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <UserAvatar name={doc.name} size="sm" />
                      <div>
                        <p className="font-medium text-navy-900">{doc.name}</p>
                        <p className="text-xs text-navy-400">{doc.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-navy-600 hidden md:table-cell">{doc.specializationName}</td>
                  <td className="px-4 py-3 text-navy-600 hidden lg:table-cell">{doc.experienceYears} yrs</td>
                  <td className="px-4 py-3 text-navy-600 hidden lg:table-cell">{formatCurrency(doc.consultationFee)}</td>
                  <td className="px-4 py-3 hidden sm:table-cell"><StatusBadge status={doc.status} /></td>
                  <td className="px-4 py-3 text-right relative">
                    <button onClick={() => setOpenMenu(openMenu === doc.id ? null : doc.id)} className="p-1.5 text-navy-400 hover:text-navy-700 hover:bg-navy-100 rounded-lg">
                      <MoreVertical className="w-4 h-4" />
                    </button>
                    {openMenu === doc.id && (
                      <div className="absolute right-4 top-full mt-1 w-44 bg-white rounded-xl shadow-elevated border border-navy-100 py-1 z-10 text-left">
                        <button onClick={() => { setOpenMenu(null); showToast('info', 'View Profile', 'Doctor profile page will open.'); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50"><Eye className="w-4 h-4" /> View</button>
                        <button onClick={() => { setOpenMenu(null); showToast('info', 'Edit Doctor', 'Edit form will open.'); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50"><Edit2 className="w-4 h-4" /> Edit</button>
                        <button onClick={() => toggleStatus(doc.id)} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-navy-700 hover:bg-navy-50">
                          {doc.status === 'active' ? <><UserX className="w-4 h-4" /> Deactivate</> : <><UserCheck className="w-4 h-4" /> Activate</>}
                        </button>
                        <button onClick={() => { setDeleteTarget(doc.id); setOpenMenu(null); }} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-error-600 hover:bg-error-50"><Trash2 className="w-4 h-4" /> Remove</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <p className="text-center text-sm text-navy-500 py-8">No doctors found</p>}
      </Card>

      <Modal open={showAddModal} onClose={() => setShowAddModal(false)} title="Add New Doctor" size="lg">
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Full Name" placeholder="Dr. John Doe" />
            <Input label="Email" type="email" placeholder="doctor@careconnect.in" />
            <Input label="Phone" placeholder="+91 98765 43210" />
            <div>
              <label className="label">Specialization</label>
              <select className="input">{specializations.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
            </div>
            <Input label="Qualification" placeholder="MBBS, MD" />
            <Input label="Experience (years)" type="number" placeholder="10" />
            <Input label="Consultation Fee" type="number" placeholder="500" />
            <Input label="Location" placeholder="City" />
          </div>
          <div>
            <label className="label">Bio</label>
            <textarea className="input resize-none" rows={3} placeholder="Doctor's professional bio..." />
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setShowAddModal(false)}>Cancel</Button>
            <Button onClick={() => { setShowAddModal(false); showToast('success', 'Doctor Added', 'New doctor has been added to the platform.'); }}>Add Doctor</Button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} title="Remove Doctor?" description="Are you sure you want to remove this doctor? This action cannot be undone." confirmLabel="Yes, Remove" />
    </DashboardLayout>
  );
}
