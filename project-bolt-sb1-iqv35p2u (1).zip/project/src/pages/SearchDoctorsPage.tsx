import { useNavigate, useSearchParams } from 'react-router-dom';
import { useState, useMemo } from 'react';
import { Search, MapPin, SlidersHorizontal, X, ChevronDown, CheckCircle2, Video, Clock } from 'lucide-react';
import { DoctorCard } from '@/components/shared/DoctorCard';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { RatingStars } from '@/components/ui/RatingStars';
import { EmptyState, CardSkeleton } from '@/components/ui/States';
import { Modal } from '@/components/ui/Modal';
import { doctors } from '@/data/doctors';
import { specializations } from '@/data/specializations';
import { cn } from '@/lib/utils';

type SortOption = 'relevance' | 'experience' | 'rating' | 'fee_low' | 'fee_high' | 'availability';

export function SearchDoctorsPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [locationQuery, setLocationQuery] = useState(searchParams.get('location') || '');
  const [selectedSpec, setSelectedSpec] = useState(searchParams.get('spec') || '');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('relevance');
  const [sortOpen, setSortOpen] = useState(false);

  const [filters, setFilters] = useState({
    specialization: searchParams.get('spec') || '',
    location: '',
    gender: '',
    minExperience: 0,
    maxFee: 5000,
    minRating: 0,
    onlineOnly: false,
  });

  setTimeout(() => setLoading(false), 500);

  const filteredDoctors = useMemo(() => {
    let result = [...doctors];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(d => d.name.toLowerCase().includes(q) || d.specializationName.toLowerCase().includes(q) || d.qualifications.toLowerCase().includes(q));
    }
    if (locationQuery) {
      const q = locationQuery.toLowerCase();
      result = result.filter(d => d.city.toLowerCase().includes(q) || d.area.toLowerCase().includes(q));
    }
    if (filters.specialization) result = result.filter(d => d.specializationId === filters.specialization);
    if (filters.location) result = result.filter(d => d.city.toLowerCase().includes(filters.location.toLowerCase()) || d.area.toLowerCase().includes(filters.location.toLowerCase()));
    if (filters.gender) result = result.filter(d => d.gender === filters.gender);
    if (filters.minExperience > 0) result = result.filter(d => d.experienceYears >= filters.minExperience);
    result = result.filter(d => d.consultationFee <= filters.maxFee);
    if (filters.minRating > 0) result = result.filter(d => d.rating >= filters.minRating);
    if (filters.onlineOnly) result = result.filter(d => d.onlineConsultation);

    switch (sortBy) {
      case 'experience': result.sort((a, b) => b.experienceYears - a.experienceYears); break;
      case 'rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'fee_low': result.sort((a, b) => a.consultationFee - b.consultationFee); break;
      case 'fee_high': result.sort((a, b) => b.consultationFee - a.consultationFee); break;
      case 'availability': result.sort((a, b) => (a.nextAvailable.includes('Today') ? -1 : 1) - (b.nextAvailable.includes('Today') ? -1 : 1)); break;
      default: result.sort((a, b) => b.rating * b.reviewCount - a.rating * a.reviewCount);
    }
    return result;
  }, [searchQuery, locationQuery, filters, sortBy]);

  const sortLabels: Record<SortOption, string> = {
    relevance: 'Relevance', experience: 'Experience', rating: 'Rating', fee_low: 'Fee: Low to High', fee_high: 'Fee: High to Low', availability: 'Earliest Availability',
  };

  const activeFilterCount = [filters.specialization, filters.gender, filters.onlineOnly ? 'online' : ''].filter(Boolean).length + (filters.minExperience > 0 ? 1 : 0) + (filters.maxFee < 5000 ? 1 : 0) + (filters.minRating > 0 ? 1 : 0);

  return (
    <div className="min-h-screen bg-navy-50">
      {/* Search header */}
      <div className="bg-white border-b border-navy-100 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
              <input type="text" placeholder="Search doctors, specialties" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="input pl-10" />
            </div>
            <div className="relative sm:w-48">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
              <input type="text" placeholder="Location" value={locationQuery} onChange={(e) => setLocationQuery(e.target.value)} className="input pl-10" />
            </div>
            <Button variant="outline" className="lg:hidden" onClick={() => setShowFilters(true)}>
              <SlidersHorizontal className="w-4 h-4" /> Filters {activeFilterCount > 0 && <span className="ml-1 px-1.5 py-0.5 bg-primary-600 text-white text-xs rounded-full">{activeFilterCount}</span>}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          {/* Desktop filter sidebar */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24">
              <FilterContent filters={filters} setFilters={setFilters} />
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-navy-600">
                {loading ? 'Searching...' : <><span className="font-semibold text-navy-900">{filteredDoctors.length}</span> doctors found{searchQuery && <> for <span className="font-semibold text-navy-900">{searchQuery}</span></>}{locationQuery && <> in <span className="font-semibold text-navy-900">{locationQuery}</span></>}</>}
              </p>
              <div className="relative">
                <button onClick={() => setSortOpen(!sortOpen)} className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-navy-700 bg-white border border-navy-200 rounded-lg hover:bg-navy-50">
                  Sort: {sortLabels[sortBy]} <ChevronDown className="w-4 h-4" />
                </button>
                {sortOpen && (
                  <div className="absolute right-0 mt-1 w-48 bg-white rounded-xl shadow-elevated border border-navy-100 py-1 z-10">
                    {(Object.keys(sortLabels) as SortOption[]).map((opt) => (
                      <button key={opt} onClick={() => { setSortBy(opt); setSortOpen(false); }} className={cn('w-full text-left px-3 py-2 text-sm hover:bg-navy-50', sortBy === opt && 'text-primary-700 font-medium')}>
                        {sortLabels[opt]}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
              </div>
            ) : filteredDoctors.length === 0 ? (
              <EmptyState
                icon={Search}
                title="No doctors found"
                description="Try changing your filters or search terms to find available doctors."
                action={<Button onClick={() => { setSearchQuery(''); setLocationQuery(''); setFilters({ specialization: '', location: '', gender: '', minExperience: 0, maxFee: 5000, minRating: 0, onlineOnly: false }); }}>Clear All Filters</Button>}
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredDoctors.map((doc) => (
                  <DoctorCard key={doc.id} doctor={doc} onView={() => navigate(`/doctors/${doc.id}`)} onBook={() => navigate(`/doctors/${doc.id}?book=1`)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      <Modal open={showFilters} onClose={() => setShowFilters(false)} title="Filters" size="md">
        <div className="p-5">
          <FilterContent filters={filters} setFilters={setFilters} />
          <div className="flex gap-2 mt-6">
            <Button variant="outline" className="flex-1" onClick={() => setFilters({ specialization: '', location: '', gender: '', minExperience: 0, maxFee: 5000, minRating: 0, onlineOnly: false })}>Clear All</Button>
            <Button className="flex-1" onClick={() => setShowFilters(false)}>Show {filteredDoctors.length} Results</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function FilterContent({ filters, setFilters }: { filters: any; setFilters: (f: any) => void }) {
  return (
    <div className="space-y-5">
      <div>
        <h4 className="text-sm font-semibold text-navy-900 mb-2">Specialization</h4>
        <div className="space-y-1.5 max-h-48 overflow-y-auto">
          {specializations.map((spec) => (
            <label key={spec.id} className="flex items-center gap-2 cursor-pointer text-sm text-navy-600 hover:text-navy-900">
              <input type="radio" name="spec" checked={filters.specialization === spec.id} onChange={() => setFilters({ ...filters, specialization: spec.id })} className="text-primary-600 focus:ring-primary-500" />
              {spec.name}
            </label>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-sm font-semibold text-navy-900 mb-2">Gender</h4>
        <div className="flex gap-2">
          {[{ v: '', l: 'All' }, { v: 'male', l: 'Male' }, { v: 'female', l: 'Female' }].map((g) => (
            <button key={g.v} onClick={() => setFilters({ ...filters, gender: g.v })} className={cn('px-3 py-1.5 text-xs font-medium rounded-lg border', filters.gender === g.v ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-navy-200 text-navy-600 hover:bg-navy-50')}>{g.l}</button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-sm font-semibold text-navy-900 mb-2">Experience</h4>
        <div className="flex gap-2">
          {[{ v: 0, l: 'All' }, { v: 5, l: '5+ yrs' }, { v: 10, l: '10+ yrs' }, { v: 15, l: '15+ yrs' }].map((e) => (
            <button key={e.v} onClick={() => setFilters({ ...filters, minExperience: e.v })} className={cn('px-3 py-1.5 text-xs font-medium rounded-lg border', filters.minExperience === e.v ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-navy-200 text-navy-600 hover:bg-navy-50')}>{e.l}</button>
          ))}
        </div>
      </div>

      <div>
        <h4 className="text-sm font-semibold text-navy-900 mb-2">Max Consultation Fee: ₹{filters.maxFee}</h4>
        <input type="range" min="100" max="5000" step="100" value={filters.maxFee} onChange={(e) => setFilters({ ...filters, maxFee: Number(e.target.value) })} className="w-full accent-primary-600" />
      </div>

      <div>
        <h4 className="text-sm font-semibold text-navy-900 mb-2">Minimum Rating</h4>
        <div className="flex gap-2">
          {[0, 3, 4, 4.5].map((r) => (
            <button key={r} onClick={() => setFilters({ ...filters, minRating: r })} className={cn('px-3 py-1.5 text-xs font-medium rounded-lg border', filters.minRating === r ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-navy-200 text-navy-600 hover:bg-navy-50')}>
              {r === 0 ? 'All' : `${r}+`}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="flex items-center gap-2 cursor-pointer text-sm text-navy-700">
          <input type="checkbox" checked={filters.onlineOnly} onChange={(e) => setFilters({ ...filters, onlineOnly: e.target.checked })} className="rounded text-primary-600 focus:ring-primary-500" />
          Online consultation only
        </label>
      </div>
    </div>
  );
}
