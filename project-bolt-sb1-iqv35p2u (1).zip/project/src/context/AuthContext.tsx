import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User, UserRole } from '@/types';

interface AuthContextValue {
  user: User | null;
  login: (email: string, password: string, role: UserRole) => Promise<{ success: boolean; error?: string }>;
  register: (data: { name: string; email: string; phone: string; password: string }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const STORAGE_KEY = 'careconnect_auth';

const demoUsers: Record<string, User> = {
  'patient@demo.com': { id: 'p1', name: 'Alex Johnson', email: 'patient@demo.com', role: 'patient' },
  'doctor@demo.com': { id: 'd1', name: 'Dr. Sarah Wilson', email: 'doctor@demo.com', role: 'doctor' },
  'admin@demo.com': { id: 'admin1', name: 'Admin User', email: 'admin@demo.com', role: 'admin' },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try { setUser(JSON.parse(stored)); } catch { /* ignore */ }
    }
  }, []);

  const login = async (email: string, password: string, role: UserRole) => {
    await new Promise((r) => setTimeout(r, 600));
    const demoUser = demoUsers[email.toLowerCase()];
    if (demoUser && demoUser.role === role && password === 'Demo@123') {
      setUser(demoUser);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(demoUser));
      return { success: true };
    }
    if (password !== 'Demo@123') {
      return { success: false, error: 'Invalid email or password. Use Demo@123 for demo accounts.' };
    }
    return { success: false, error: 'No account found with this email. Try a demo account.' };
  };

  const register = async (data: { name: string; email: string; phone: string; password: string }) => {
    await new Promise((r) => setTimeout(r, 800));
    const newUser: User = { id: `p_${Date.now()}`, name: data.name, email: data.email, role: 'patient' };
    setUser(newUser);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
